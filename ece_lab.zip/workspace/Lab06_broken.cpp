
// Ohms law structure assignment - part a starter code
//
// This code solves the basic case of one resistor and one voltage source
// 
// Please convert this starter code to use functions as much as possible 
// It will become part A of the laboratory
// 
// You need to create at least 5-functions

#include <iostream>
#include <string>
#include <vector>

using namespace std;

// You must use this structure
struct node {
    string name;
    double resistance;
    double voltage_across;
    double power_across;
};

// An Example of the type of function you may want to create
string nodeName() {
    string node_name;
    cout << "Enter Node Name: ";
    cin >> node_name;
   
    return node_name;
}

//
double volt(){
    double source_voltage;
    cout << "Enter Source Voltage: ";
    cin >> source_voltage;
    return source_voltage;
}
node input_data(){
    node N;
    cout << "name of resistor: " << endl;
    cin >> N.name;
    cout << "Resistence value " << endl;
    cin >> N.resistance;
    return N;
}
vector<node> individualResistor(){
    vector<node> record;
    int flag = 1;
    do{
        node temp;
        temp = input_data();
        record.push_back(temp);
        cout << "Do you want another resistor(1 to continue) ";
        cin >> flag;
    } while(flag == 1);
    return record;
}
double TOTALRESIST(vector<node> R){
    double total = 0;
    for(int i =0; i < R.size(); i++){
        total = total + R[i].resistance;
    }
    return total;
}
vector<node> volt_across(double series_cur, vector<node> R){
    for(int i =0; i < R.size(); i++){
        R[i].voltage_across = series_cur / R[i].resistance;
    }
    return R;
}
vector<node> pow_across(double series_cur, vector<node> R){
    for(int i =0; i < R.size(); i++){
        R[i].power_across = R[i].voltage_across * series_cur;
    }
    return R;
}
vector<node> display_fun(vector<node> R){
    for(int i =0; i < R.size(); i++){
        cout << "Node name: " <<R[i].name << endl;;
        cout << "Node resistance: " << R[i].resistance << "-Volts" << endl;
        cout << "Node Voltage Across: " << R[i].voltage_across << "-Ohms" << endl;
        cout << "Node power_across: " << R[i].power_across << "-Watts" << endl;
    }
    return R;
}
//
int main() {
    vector<node> R;
    
    double source_voltage = volt(); 
    
    // Enter basic Node Information
    R = individualResistor();
   
    // Calculate series current for the one-node network
   double total_resistence = TOTALRESIST(R);
    double series_current = source_voltage/ total_resistence;

    // Calculate voltage across the restistor 
    R = volt_across(series_current, R);
    R = pow_across(series_current, R);

    // Display Network Information
    cout << "Series Network: " << endl;
    cout << "Source Voltage: " << source_voltage << "-Volts" << endl;
    cout << "Total Resistance: " << total_resistence << "-Ohms" << endl;
    cout << "Series Current: " << series_current << "-Amperes" << endl;
    // Display Node information
    R = display_fun(R);
    
    int x = 0;
    while(x==0){
        int edit_num;
        cout << "would you like to edit the data (select 1-7) : " << endl;
        cin >> edit_num;
        switch(edit_num){
            case 1:
                cout << "new voltage: " << endl;
                cin >> source_voltage;
                break;
            case 2:
                cout << "add a new resistor" << endl;
                individualResistor();
                volt_across(series_current, R);
                pow_across(series_current, R);
                break;
            case 3:
                int deleting;
                cout << "delete resistor: " << endl;
                cout << "Which resistor number to delete" << endl;
                cin >> deleting;
                R.erase(R.begin()+(deleting));
                break;
            case 4:
                int editing;
                cout << "edit a resistor(pick a resistor): " << endl;
                cin >> editing;
                cout << "New name of Resistor: " << endl;
                cin >> R[editing].name;
                cout << "New value of reistence: " << endl;
                cin >> R[editing].resistance;
                R[editing].voltage_across = series_current / R[editing].resistance;
                R[editing].power_across = R[editing].voltage_across * series_current;
                break;
            case 5:
                cout << "Group add a series of resistors: " << endl;
                TOTALRESIST(R);
                break;
            case 6:
                cout << "Display network: " << endl;
                cout << "Series Network: " << endl;
                cout << "Source Voltage: " << source_voltage << "-Volts" << endl;
                cout << "Total Resistance: " << total_resistence << "-Ohms" << endl;
                cout << "Series Current: " << series_current << "-Amperes" << endl;
                display_fun(R);
                break;
            case 7:
                cout << "Quit program: " << endl;
                x=1;
                break;
        }
    }
   
    return 0;
}