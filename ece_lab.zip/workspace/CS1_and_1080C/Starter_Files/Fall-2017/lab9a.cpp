#include <iostream>
#include <vector>

using namespace std;

struct node {
    double resistance;
    double voltage_across;
    double power_across;
};

int main() {
    node N1;
    double in_voltage;
    
    cout << "Enter Voltage: ";
    cin >> in_voltage;
    
    cout << "Resistor: ";
    cin >> N1.resistance;
    
    double total_resistance = N1.resistance;
    
    double current = in_voltage/total_resistance;
    
    N1.voltage_across = current * N1.resistance;
    N1.power_across = N1.voltage_across * current;
    
    cout << N1.voltage_across << endl;
    cout << N1.power_across << endl;
    return 0;
}