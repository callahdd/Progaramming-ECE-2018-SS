
#include <cmath>
#include <string>

using namespace std;

const double PI = atan(1.0)*4.0;
const double PRECISION = 0.00001;

double factorial(double n){
}

double degreesToRadians(double angle_in_degrees){
}

bool isPrime(int number){
}

int countChars(string input, char which_char){
}

bool containsDups(string sarray[], int length){
}

const int LEFT_DIR = 1;
const int RIGHT_DIR = 2;

string rotateString(string to_rotate, int direction, int offset){
}
