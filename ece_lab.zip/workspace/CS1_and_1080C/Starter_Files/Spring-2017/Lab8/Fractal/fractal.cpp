/*    @file image.cpp
      @author <-- Fill in your name here -->
      @date <-- Fill this in -->
*/
// Example of generating and saving a PNG image.
#include <iostream>
#include <stdlib.h>
#include <sstream>
#include <complex>


#include <QImage>
#include <QPixmap>
#include <QFile>

using namespace std;


int main(int argc, char* argv[]){
    // We accept 3 command-line paramters, filename, x and y
    // If no paramters are given, it will save a 800x600 image
    // to image.png

    string filename = "image.png";
    if(argc >= 2){
        filename = argv[1];
    }

    // Default Image size
    int width  = 800;
    int height = 600;

    if(argc >= 3){  // Width was given
        width = atoi(argv[2]);
    }
    if(argc >= 4){  // Height was given
        height = atoi(argv[3]);
    }

    // The image will be from -100 to +100 in both axes and scaled to
    // fit the requested image size.
    double urr = 100.0; // UpperRightReal (x)
    double uri = 100.0; // UpperRightImaginary (y)

    double llr = -100.0;
    double lli = -100.0;

    double dx = (urr-llr) / (double)width;
    double dy = (uri-lli) / (double)height;

    // Sample complex number math
    //complex<double> A(5.,5.), B(5.,5.);
    //cout << A - B << endl;

    // Setup the image in Qt
    QImage img(width, height, QImage::Format_RGB32);

    // Fill background with white
    img.fill(QColor(Qt::white).rgb());

    // Build image one pixel at a time.
    for(int x = 0; x < width; x++){
        for(int y = 0; y < height; y++){
            // Calculate where in the complex plane this point is
            double real = (double)x * dx + llr;
            double imag = (double)y * dy * -1 + uri;
            // Now real and complex will be x and y from -100 to +100

            // For this example, just do a fade.
            // There are 3 channels, R,G,B  which you can assign to.
            // Each channel takes a single byte 0-255
            img.setPixel(x, y, qRgb((int)real % 256, // RED
                                    (int)(real * imag / 4) % 256, // GREEN
                                    (int)imag % 256)); // BLUE
        }
    }
    // save the image
    cout << "Saving: " << filename << " Width: " << width;
    cout << " Height: " << height << endl;
    // Saves the image
    QFile file(filename.c_str());
    img.save(file.fileName());

    // This requires imagemagick. It works on Windows
    // You will need to change imdisplay to display on Mac or Linux
    string display_it = "display " + filename;
    system(display_it.c_str());

    return 0;
}
