// Author: <fill in your name>
// Source File: string-stats.cpp
// Description: Various string statistics

#include <cmath>
#include <cctype>
#include <string>
#include <vector>

using namespace std;


// Count the upper case characters in string st
unsigned upperCaseChars(const string& st){
}

// Count the lower case characters in string st
unsigned lowerCaseChars(const string& st){
}

// Count the punction characters in string st
// use ispunct to determine if the character is a
// punction
unsigned numPunct(const string& st){
}

// Convert string st to uppercase returning a new 
// string
string convertToUpper(const string& st){
}

// Remove all the spaces (use ispace) from string st and
// return a new string
string removeSpaces(const string& st){
}

// Count the number of words in a string st
unsigned numWords(const string& st){
}


// Count the individual alphabetic characters
// Treat lowercase and uppercase the same
vector<int> characterCounts(const string& st){
  vector<int> ret(26);


  return ret;
}

