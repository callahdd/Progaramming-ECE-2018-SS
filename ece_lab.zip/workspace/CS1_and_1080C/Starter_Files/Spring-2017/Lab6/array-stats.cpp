
/*
Name: <fill me in>
Date: <fill me in>
Assignment: <fill me in>
Description: <fill me in>
*/
#include <iostream>
#include <string>
#include <iomanip>
#include <cstdlib>
#include <cmath>

using namespace std;


// Helper function: Provider for you to display array
void display_array(int array[], unsigned length){
  cout << setw(6) << "Index" << setw(8) << "Value" << endl;
  for(unsigned i = 0; i < length; i++){
     cout << setw(6) << i << setw(8) << array[i] << endl;
  }
}

// Just return the Minimum value int a and int b
int Min(int a, int b){
  // TODO: Fill me in
}

// Just return the Maximum value int a and int b
int Max(int a, int b){
  // TODO: Fill me in
}


// init function sets all locations of an array to the "value"
// specified
void init(int array[], unsigned length, int value){
  // TODO: Fill me in
}

// Return the sum of array elements. An empty array has a zero sum
int arraySum(int array[], unsigned length){
  // TODO: Fill me in
}

// Return the mean of all array elements. An empty array has a zero mean
// Use arraySum above to calculate the Sum
double arrayMean(int array[], unsigned length){
  // TODO: Fill me in
}

// Return the minimum value of all array elements. 
// An empty array has a zero minimum value
// You must use Min() above in this function
int arrayMin(int array[], unsigned length){
  // TODO: Fill me in
}

// Return the maximum value of all array elements. 
// An empty array has a zero minimum value
// You must use Max() above in this function
int arrayMax(int array[], unsigned length){
  // TODO: Fill me in
}

// Return the standard Deviation of all array elements. An empty array has 
// a zero standard deviation value
// You should use the arrayMean() function above
double arrayStdDev(int array[], unsigned length){
  // TODO: Fill me in
}

// Return the location in the array of the "search_value" 
// An empty array or a failed search should return a -1 
// Please start your search at an index of "stating_position"

// Please do not remove the default parameter (ie = 0) from this function
// defination
int arrayFind(int array[], unsigned length, 
	int search_value, unsigned starting_position = 0){
  // TODO: Fill me in
}

// Return the number of times the "search_value"  was found in the array.  
// Return 0 if the length is 0 or less.
int count(int array[], unsigned length, int search_value){
  // TODO: Fill me in
}

// Returns the array max - array min.  
// Return 0 if the length is 0 or less
// Should use arrayMax and arrayMin above
int range(int array[], unsigned length){
  // TODO: Fill me in
}

// Return a boolean: 
// true if the array contains the same integer at least twice 
// false if all values in the array are unique.
bool containsDups(int array[], unsigned length){
  // TODO: Fill me in
}

// Returns a boolean, true if the array is sorted from smallest to largest, 
// false if it is not sorted.  Adjacent duplicate elements are allowed.  
// A list of 1 or fewer elements is sorted
bool isSorted(int array[], unsigned length){
  // TODO: Fill me in
}


