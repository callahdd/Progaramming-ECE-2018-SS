
// Name:
//
// Purpose: To demostrate string functions by using basic crytopgraphy  methods
//



#ifndef CRYPTO_HEADER
#define CRYPTO_HEADER
#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>

using namespace std;

class Crypto {
public:
    void DisplayFile(string filename);
    void EncryptFile(string cipher_key, string filename_from, string filename_to);
    void DecryptFile(string cipher_key, string filename_from, string filename_to);
    string EncryptString(string &cipher_key, string string_to_be_encrypted);
    string DecryptString(string &cipher_key, string string_to_be_decrypted);
private:
    string cipher_key;
    void RotateCipherKey();
    char substitution_cipher(char char_to_encrypt);
    char reverse_substitution_cipher(char char_to_encrypt);
};
#endif
