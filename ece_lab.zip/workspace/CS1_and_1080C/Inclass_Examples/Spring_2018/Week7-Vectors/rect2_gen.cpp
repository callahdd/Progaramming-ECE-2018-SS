

#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>

using namespace std;

struct coordxy {
    float x;
    float y;
};
struct rect {
    coordxy p1;
    coordxy p2;
    float a;
    float p;
    bool issquare;
};

void printCoord(coordxy p){
    cout << p.x << endl;
    cout << p.y << endl;
}

float calcWidth(coordxy p1, coordxy p2) {
    return abs(p1.x - p2.x);
}

float calcHeight(coordxy p1, coordxy p2) {
    return abs(p1.y - p2.y);
}

void inputRect(struct rect &r){
    cout << "Enter Lower Corner: ";
    cin >> r.p1.x;
    cin >> r.p1.y;
    cout << "Enter Upper Corner: ";
    cin >> r.p2.x;
    cin >> r.p2.y;
}

void calcRect(struct rect &r){
    float w = calcWidth(r.p1, r.p2);
    float h = calcHeight(r.p1, r.p2);
    
    r.a = w * h;
    r.p = 2 * w + 2 * h;
    r.issquare = (w == h);
    
}

void printRect(struct rect r){
    printCoord(r.p1);
    printCoord(r.p2);
    
    cout << "W: " << calcWidth(r.p1,r.p2)<< endl;
    cout << "H: " << calcHeight(r.p1, r.p2) << endl;
    cout << "P: " << r.p << endl;
    cout << "A: " << r.a << endl;
    cout << "IsSquare: " << (r.issquare ? "YES" : "NO") << endl;
}

int main() {
    rect rect1 = {};
    
    inputRect(rect1);
    calcRect(rect1);
    printRect(rect1);
    
    vector <rect> rectangles;
    rect temp;
    inputRect(temp);
    
    rectangles.push_back(temp);
    
    calcRect(rectangles[0]);
    printRect(rectangles[0]);
    
    return 0;
}