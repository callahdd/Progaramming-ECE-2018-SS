

#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

struct rect {
    float h;
    float w;
    float a;
    float p;
    bool issquare;
};

void inputRect(struct rect &r){
    cout << "Enter W: ";
    cin >> r.w;
    cout << "Enter H: ";
    cin >> r.h;
}

void calcRect(struct rect &r){
    r.p = r.h + r.h + r.w + r.w;
    r.a = r.h * r.w;
    r.issquare = (r.w == r.h);
}

void printRect(struct rect r){
    cout << "W: " << r.w << endl;
    cout << "H: " << r.h << endl;
    cout << "P: " << r.p << endl;
    cout << "A: " << r.a << endl;
    cout << "IsSquare: " << (r.issquare ? "YES" : "NO") << endl;
}

int main() {
    rect rect1 = {};
    inputRect(rect1);
    calcRect(rect1);
    printRect(rect1);
    
    
    
    
    
    return 0;
}