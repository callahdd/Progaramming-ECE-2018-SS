All Inclass Examples starting in Spring of 2016. Arranged by Instructor and Week. 
