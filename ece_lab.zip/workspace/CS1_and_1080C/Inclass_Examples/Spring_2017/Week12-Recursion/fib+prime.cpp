
#include <iostream>

using namespace std;


int rFib(int n) {
	if(n == 0) return 0;
	if(n == 1) return 1;

	return rFib(n - 1) + rFib(n - 2);
}

int iFib(int n) {
	if(n == 0) return 0;
	if(n == 1) return 1;

	int n0 = 0;
	int n1 = 1;

	int fib = n0 + n1;
	for(int i = 2; i <= n; i++) {
		fib = n0  + n1;
		n0 = n1;
		n1 = fib;

	}
	return fib;
}

unsigned fact(int N) {
	if(N <= 0) 
		return 1;
	if(N == 1) 
		return 1;

	return N*fact(N - 1); 
}

int main(){

  cout << rFib(10) << endl;
  cout << iFib(10) << endl;
  cout << fact(10) << endl;
  //cout << fib(2) << endl;
  //cout << fib(3) << endl;
  //cout << fib(4) << endl;

} 
