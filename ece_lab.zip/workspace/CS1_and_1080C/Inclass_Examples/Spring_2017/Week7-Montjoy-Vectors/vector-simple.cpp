#include <iostream>
#include <vector>
#include <cstdlib>
#include <string>

using namespace std;


string GenRandomString() {

   string x;

   int size_of_x = (rand()%12)+1;

   for(int i = 0;i < size_of_x; i++){
	 x += rand()%26 + 'a';
   }

   return x;
}


int main() {

  srand(time(0));
  vector <string> strings;

  cout << "Empty() ? " << strings.empty() << endl;

  strings.push_back(GenRandomString());
  strings.push_back(GenRandomString());
  strings.push_back(GenRandomString());
  strings.push_back(GenRandomString());
  strings.push_back(GenRandomString());

  cout << "Empty() ? " << strings.empty() << endl;
  cout << "Size() ? " << strings.size() << endl;

  for(int i = 0; i < strings.size(); i++) {
    cout << strings[i] << endl;
  }

  strings.pop_back();
  cout << "After Popback" << endl;


  for(int i = 0; i < strings.size(); i++) {
    cout << strings[i] << endl;
  }

  strings.clear();
  cout << "Empty() ? " << strings.empty() << endl;
  cout << "Size() ? " << strings.size() << endl;


  	
  return 0;
}


