#include <iostream>
#include <vector>
#include <cstdlib>
#include <string>

using namespace std;


string GenRandomString() {

   string x;

   int size_of_x = (rand()%12)+1;

   for(int i = 0;i < size_of_x; i++){
         x += rand()%26 + 'a';
   }

   return x;
}

void display_vector(vector <string> display) {
  for(int i = 0; i < display.size(); i++)
	cout << display[i] << endl;
}

int main() {

  srand(time(0));
  vector <string> strings;
  
//string b[] = {"abc2", "cba!", "9zyz"};

  strings.push_back("abc2");
  strings.push_back("cba!");
  strings.push_back("9xyz!");

  int alpha = 0;
  int numbers = 0;
  int punct = 0;
  for(int r = 0; r < strings.size(); r++) {
        string temp = strings[r];
        for( int c = 0; c < temp.length(); c++) {
                //cout << temp[c] << endl;
                if(isalpha(temp[c])) alpha++;
                if(isdigit(temp[c])) numbers++;
                if(ispunct(temp[c])) punct++;
        }

  }
  cout << "Alpha Chars: " << alpha << endl;
  cout << "Numbers: " << numbers << endl;
  cout << "Punction: " << punct << endl;
  display_vector(strings);
  	
  return 0;
}


