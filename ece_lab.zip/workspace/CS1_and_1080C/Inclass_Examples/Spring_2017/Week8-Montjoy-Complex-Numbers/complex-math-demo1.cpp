
#include <iostream>
#include <complex>
#include <cmath>

const double PI = atan(1.0)*4;
using namespace std;


// Just add two complex numbers and a floating number (real)
complex<double> doAdd(complex<double> X, complex<double> Y) {
    return X + Y + 1.0;
}

// Difference between the magitude of X and Y
// good to show how to check coverengce
double absDifference(complex<double> X, complex<double> Y) {
    return abs(X - Y); // fractal
}

int main() {
    // Declare two complex numbers
    complex<double> X(5,10), Y(6, 8);
    complex<double> A;
    cout << doAdd(X, Y) << endl;
    //

    X = complex<double>(7, 5); // fractal
    A = X + Y;
    cout << A << endl;
    A = X - Y;
    cout << A << endl;
    cout << abs(A) << endl;

    // Normal complex number add. No need to call functions
    complex<double> Z = X + Y + 1.0;

    cout << Z.real() << " + j" << Z.imag() << endl;

    cout << absDifference(X, Y) << endl;

    // int's are not constructor overloaded so you have to do the following
    // instead:

    cout << X + Y + complex<double>(1) << endl;

    A = polar(5.0, PI);
    cout << "Magnitude: 5 at an angle of PI" << endl;
    cout << " is " << A << endl;
    A = polar(5.0, 0.0);
    cout << "Magnitude: 5 at an angle of 0.0" << endl;
    cout << " is " << A << endl;
    return 0;
}

// Sample complex number math
//complex<double> A(5.,5.), B(5.,5.);
//cout << A - B << endl;
