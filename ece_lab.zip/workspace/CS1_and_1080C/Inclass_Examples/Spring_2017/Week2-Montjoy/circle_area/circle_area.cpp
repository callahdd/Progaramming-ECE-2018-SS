#include <iostream>
#include <cmath>

const double PI = atan(1.0)*4;

using namespace std;

int main()
{
    double radius = 0;
    double answer = 0;

    cout << "Enter Radius: " ;
    cin >> radius;


    answer = radius*radius*PI;

    //answer = pow(radius, 2.0) * PI;

    cout << "Surface Area: " << answer << endl;


    return 0;
}
