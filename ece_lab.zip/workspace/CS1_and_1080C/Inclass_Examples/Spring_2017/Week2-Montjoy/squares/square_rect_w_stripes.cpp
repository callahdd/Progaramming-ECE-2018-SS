#include <iostream>

using namespace std;

int main()
{
    char fill_char_even = 'A';
    char fill_char_odd = 'B';
    int line_length = 10;

    for( int r = 0; r < line_length; r++)
    {
          for(int c = 0; c < line_length; c++)
          {
              if((c % 2) == 0)
                cout << fill_char_even ;
              else
                  cout << fill_char_odd ;
          }
          fill_char_even++;
          fill_char_odd--;

          cout << endl;
    }
}
