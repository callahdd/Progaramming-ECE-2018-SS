#include <iostream>

using namespace std;

int main()
{
    int k = 2;
  //int done = 0;
    do {

        cout << "Enter K: ";

        cin >> k;
        switch(k)
        {
    //        case 0:
      //          done = 1;
            case 1:
                cout << "case" << endl;
            break;

            case 2:
            case 3:
                cout << k*k << endl;
            break;

            case 5:
                cout << "case 5" << endl;
            case 6:
                cout << "case 6" << endl;
            break;

            default:
            cout << "default" << endl;
            break;
        }
    } while(k != 0);
}

