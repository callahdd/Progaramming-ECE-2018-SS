#include <iostream>

using namespace std;

int main()
{
    int x = 0, y = 2, z = 4;

    if(x)
        cout << " x is true" << x << endl;

    if(!x)
        cout << "x in not true" << x << endl;

    if(x > z)
        cout << "x greater than z" << endl;

    if(x > z || y < x)
        cout << "x greater than z or y less than x" << endl;
    else
        cout << "something" << endl;

    if(x > z) {
        cout << "x greater than z" << endl;

    } else if(y < x) {
         cout << "y less than x" << endl;

    } else {
           cout << "something" << endl;
    }


    return 0;
}
