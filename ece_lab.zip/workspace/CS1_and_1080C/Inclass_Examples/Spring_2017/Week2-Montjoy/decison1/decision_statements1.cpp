#include <iostream>

using namespace std;

int main(){
    int a = 2;
    int b = 3;

    if(a > b){
        cout << "a greater than b" << endl;
        cout << "b " << b << endl;
    }else if(a == b){
        cout << "b equal a" << endl;

    }else{
cout << "b less than a" << endl;

    }
}
