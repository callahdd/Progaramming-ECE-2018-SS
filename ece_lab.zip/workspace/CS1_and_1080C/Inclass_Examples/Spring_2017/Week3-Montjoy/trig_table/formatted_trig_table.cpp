#include <iostream>
#include <cmath>
#include <iomanip>

const double PI = atan(1.0)*4;

using namespace std;

int main()
{
    double angle = 0;

    cout << setw(8)
         << "rad" << setw(8) << "degrees" << setw(12)
         << "cosine" << setw(12)
         << "sine" << endl;

    while(angle >= 0){
        double rad = angle*PI/180.0;

        cout << fixed << setprecision(4) << setw(8)
             << rad << setw(8) << setprecision(0) << angle << setw(12)
             << setprecision(4) << cos(rad) << setw(12)
             << sin(rad) << endl;
        angle += 15;
    }
    return 0;
}
