#include <iostream>
#include <iomanip>
#include <cctype>

using namespace std;

int main()
{

    char ascii_value = 0;
    int non_print_count = 0;

    for(int a = 0; a < 127; a++){
        if(isalnum(a)){
            cout << setw(10) << (char)a << setw(10) << a << endl;
        }else{
            non_print_count++;
        }
    }
    cout << non_print_count << endl;
    return 0;
}
