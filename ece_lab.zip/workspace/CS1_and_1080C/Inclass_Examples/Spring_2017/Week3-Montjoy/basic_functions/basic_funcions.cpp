#include <iostream>
#include <string>

using namespace std;

string createString(string x, string y){
    return x + y;
    //string retval;
    //reval = x + y;
   // return retval;
}

int calc(int x, int y){
    return x + y;
}

int isEven(int x){
    if(x % 2 == 0)
        return true; // 1
    return false; // 0
}

void helloWorld(string bob)
{
  cout << "Hello " + bob << endl;
}

int main()
{
    string bob = "bob";

    helloWorld(bob);
    string zilda = "zzzzz";
    helloWorld(zilda);
    string recived = createString(bob, zilda);

    cout << recived << endl;

    cout << createString(bob, zilda) << endl;
    int k = 9, j = 6;

    int result = calc(k,j);
    cout << result << endl;

    if(isEven(k)){
        cout << "k is even" << endl;
    }else{
        cout << "k is odd" << endl;
    }

    return 0;
}
