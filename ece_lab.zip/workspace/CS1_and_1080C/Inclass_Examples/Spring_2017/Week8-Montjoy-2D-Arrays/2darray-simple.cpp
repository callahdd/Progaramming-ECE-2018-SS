
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

void display2DArray(int array[][10], int row_count, int col_count) {
   int row;
   int col;
   for(row = 0; row < row_count; row++){
     for(col = 0; col < col_count; col++){
	cout <<array[row][col] << "\t";
     }
     cout << endl;
   }
}

void randomlyFill(int array[][10], int row_count, int col_count) {
   int row;
   int col;
   for(row = 0; row < row_count; row++){
     for(col = 0; col < col_count; col++){
	array[row][col] = rand()%20;
     }
   }
}

int sum2darray(int array[][10], int row_count, int col_count) {
   int row;
   int col;
   int sum = 0;
   for(row = 0; row < row_count; row++){
     for(col = 0; col < col_count; col++){
	sum += array[row][col];
     }
   }
   return sum;
}

int main() {

   srand(time(0));

   int array[5][10] = {0};

   int row;
   int col;

   for(row = 0; row < 5; row++){
     for(col = 0; col < 10; col++){
	array[row][col] = row*col;
     }
   }

   for(row = 0; row < 5; row++){
     for(col = 0; col < 10; col++){
	cout <<array[row][col] << "\t";
     }
     cout << endl;
   }
    display2DArray(array, 5, 10) ;
     randomlyFill(array, 5, 10) ;
    cout << endl;
    display2DArray(array, 5, 10) ;
cout << sum2darray(array, 5, 10) << endl;;
 
}
