#include <iostream>

using namespace std;


class pointerPractice {
	public:
	pointerPractice() { a = c = 0; b = new int; }
	pointerPractice(int in_a, int *in_b, int in_c) { a = in_a; c = in_c; b = in_b; }
	void setA(int &a_ref_value) {
		a = a_ref_value;
	}

	void setB(int *b_ptr) {
		b = b_ptr;
	}

	void setC(int c_pass_by_value) {
		c = c_pass_by_value;
	}

	int *getA() {
		return &a;
	}
	int *getB() {
		return b;
	}
	int getC() {
		return c;
	}
	private:
		int a;
		int *b;
		int c;
};

int main() {
 	pointerPractice VAR1;

	int *X = new int;

	*X = 45;


	cout << "getA()\t" << VAR1.getA() << endl;
	cout << "getB()\t" << VAR1.getB() << endl;
	cout << "getC()\t" << VAR1.getC() << endl;
	cout << "getA()\t" << *(VAR1.getA()) << endl;

	VAR1.setB(X);
	VAR1.setC(*X);
	cout << "getB()\t" << VAR1.getB() << endl;
	cout << "getC()\t" << VAR1.getC() << endl;
   

 return 0;
}
