#include <iostream>

using namespace std;

void FunA(int &a) {
 a = a * a;
}

void FunB(int *b) {
 *b = *b * *b;
}

void FunC(int c) {
  c = c * c;
}

int main()
{

 int x,y,z;


 x = 3;
 y = 7;
 z = 9;

 cout << x << "\t" << y << "\t" << z << endl;
 FunA(x);
 FunB(&y);
 FunC(z);
 cout << x << "\t" << y << "\t" << z << endl;
 return 0;
}
