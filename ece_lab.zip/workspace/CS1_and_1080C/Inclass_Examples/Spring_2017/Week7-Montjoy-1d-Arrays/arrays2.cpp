
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>

using namespace std;

const unsigned int MAX_ARRAY_LENGTH = 10;


// display array as a column
void display_array(int array[], const int number_of_values){
 cout << "Array Values" << endl;
 cout << setw(6) << "Index" << setw(10) << "Value" << endl;
 for(unsigned int i = 0; i < number_of_values; i++){
   cout << setw(6) << i << setw(10) << array[i] << endl;
 }

 cout << endl;
}

int arraySum(int array[], const int number_of_values){
  int  sum = 0;
  for(unsigned int i = 0; i < number_of_values; i++){
	sum = sum + array[i];
  }
  return sum;
}

// Enter only values greater than zero and not to exceed array_max_size_values
void enter_array_values(int array[], int &number_of_values, const int array_max_size){

  cout << "Enter a series of values greater than or equal to zero (a negative number exits)" << endl;
  int value = 0;
  number_of_values = 0;
  do {
    cout << "Enter Value: ";
    cin >> value;
    if(value >= 0){
      array[number_of_values] = value;
      number_of_values++;
    }
  } while(value >= 0 && number_of_values < array_max_size);

}

int max_value(int size_of_array, int array[], int &max_value){
 int max_loc = 0;
 for(unsigned int i = 0; i < size_of_array; i++){
	if(array[max_loc] <= array[i])
		max_loc = i;

 }
 max_value = array[max_loc];
 return max_loc;
}

int main(){

  int number_of_values = 0;
  int x[MAX_ARRAY_LENGTH] = {0};
  
  enter_array_values(x, number_of_values, MAX_ARRAY_LENGTH);
  int sum = arraySum(x, number_of_values);

  display_array(x,  number_of_values);
  cout << "Sum: " << sum << endl;
  cout << "Mean: " << static_cast<double>(sum)/number_of_values << endl;
  int max = 0;
  int max_loc = max_value(number_of_values, x, max);
  cout << "Max: " << max << " which is located at " << max_loc << endl;
 
  return 0;
}



