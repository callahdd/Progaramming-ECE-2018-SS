
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <cmath>

using namespace std;

const unsigned int MAX_ARRAY_LENGTH = 10;

// display array as a column
void display_binary(int array[], const int number_of_values){
 cout << "Binary Number: ";
 for(unsigned int i = 0; i < number_of_values; i++){
   cout << array[i];
 }

}

// Enter only values greater than zero and not to exceed array_max_size_values
void enter_array_values(int array[], int &number_of_values, const int array_max_size){

  cout << "Enter a series of values greater than or equal to zero (a negative number exits)" << endl;
  int value = 0;
  number_of_values = 0;
  do {
    cout << "Enter Value: ";
    cin >> value;
    if(value >= 0){
      array[number_of_values] = value;
      number_of_values++;
    }
  } while(value >= 0 && number_of_values < array_max_size);

}

int binary2decimal(int array[], const int number_of_values){

   int bin_val  = 0;
   int count = number_of_values-1;
   for(int i = 0; i < number_of_values; i++){
     int bit = array[i]*pow(2, count);
     bin_val += bit;
     count--;
   }
   return bin_val;

}

void reverseArray(int array[], int number_of_values) {

 for(unsigned int i = 0; i < number_of_values/2; i++){
    unsigned temp = array[i];
    array[i] = array[number_of_values - i - 1];
    array[number_of_values - i - 1] = temp;
  }
}

// Convert a decimal value to a binary number and store it 
// in the array
void decimal2binary(int array[], int &number_of_values, int decimal){

  int reminder = 0;
  number_of_values = 0;
  while(decimal > 0){
    reminder = decimal%2;
    decimal = decimal/2;
    array[number_of_values] = reminder;
    number_of_values++;
  }
  reverseArray(array, number_of_values);
}

int main(){

  int number_of_values = 0;
  int x[MAX_ARRAY_LENGTH] = {0};
  
  enter_array_values(x, number_of_values, MAX_ARRAY_LENGTH);
  display_binary(x,  number_of_values);

  int decimal_value = binary2decimal(x, number_of_values);

  cout << "decimal number: " << decimal_value << endl;

  cout << "Enter Decimal Value: " ;
  cin >> decimal_value;
  decimal2binary(x, number_of_values, decimal_value);

  cout << "A Decimal value of " << decimal_value  << " equals ";
  display_binary(x,  number_of_values);
  cout << " in binary " << endl;
 
  return 0;
}



