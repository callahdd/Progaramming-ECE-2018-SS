
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

const unsigned int ARRAY_LENGTH = 10;

int max_value(int size_of_array, int array[], int &max_value){
 int max_loc = 0;
 for(unsigned int i = 0; i < size_of_array; i++){
	if(array[max_loc] <= array[i])
		max_loc = i;

 }
 max_value = array[max_loc];
 return max_loc;
}

int main(){

 int x[ARRAY_LENGTH] = {0};

 srand(time(0));


 for(unsigned int i = 0; i < ARRAY_LENGTH; i++){
	x[i] = rand()%100;
 }
 for(unsigned int i = 0; i < ARRAY_LENGTH; i++){
	cout << i << "\t" << x[i] << endl;
 }


 int  sum = 0;
 for(unsigned int i = 0; i < ARRAY_LENGTH; i++){
	sum = sum + x[i];

 }
 cout << sum/ARRAY_LENGTH;
 cout << "\n";
 int max;
 int max_loc = max_value(ARRAY_LENGTH, x, max);
 cout << max_loc << "\t" << max;
 cout << "\n";

 
}



