
#include <iostream>

using namespace std;

int main() {
  int *a;
  int *t;

  a = new int [10];


  cout << *a << "\t";
  cout << a[0] << "\t";
  cout << a << endl;

  for ( int i = 0; i < 10; i++) {
	a[i] = i*i;
  }

// sdfsd
  t = new int [20];
  for ( int i = 0; i < 10; i++) {
	t[i] = a[i];
  }

  delete  [] a;
  a = t;
// 
  for ( int i = 0; i < 20; i++) {
	a[i] = i;
  }

  for ( int i = 0; i < 20; i++) {
	cout << a[i] << endl;
  }

  int *p = a;

  for(int i = 0; i < 20; i++) {
    cout << *p << "\t";
    cout << p << endl;
    p++;
  }

  for(;;) {
	int *new1 = new int [100000];
  }
  
  return 0;
}
