#include <iostream>
#include <cctype>
#include <fstream>
#include <ostream>
#include <iostream>

using namespace std;

void displayFile(string in_file) {
    ifstream inputFile;
    string inputString;

    inputFile.open(in_file.c_str());

    if(!inputFile) return;

    while(getline(inputFile, inputString)) {
        cout << inputString << endl; 
    }
    inputFile.close();
}
int main() {

   string filename = "";
   cout << "File to Display: ";
   cin >> filename;

   displayFile(filename);

   return 0;
}
