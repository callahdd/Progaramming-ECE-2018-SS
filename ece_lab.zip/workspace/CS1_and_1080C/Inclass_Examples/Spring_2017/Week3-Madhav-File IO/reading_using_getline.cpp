#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>

using namespace std;

int main()
{
  ifstream myfile;                           
  myfile.open("numbers.txt");
  
  if(!myfile)
	 cout << "File not found" << endl;
  string input; 
  while(getline(myfile, input)){
	int num = atoi(input.c_str());
  	cout << num << endl; 
  }
  myfile.close();
  return 0;
}
