#include <string>
#include <iostream>
#include <cctype>

using namespace std;

int main(){

  string a = "abc";

  string b[] = {"abc2", "cba!", "9zyz"};

  int alpha = 0;
  int numbers = 0;
  int punct = 0;
  for(int r = 0; r < 3; r++) {
	string temp = b[r];
	for( int c = 0; c < temp.length(); c++) {
		//cout << temp[c] << endl;
		if(isalpha(temp[c])) alpha++;
		if(isdigit(temp[c])) numbers++;
		if(ispunct(temp[c])) punct++;
	}
	
  }
  cout << "Alpha Chars: " << alpha << endl;
  cout << "Numbers: " << numbers << endl;
  cout << "Punction: " << punct << endl;


}
