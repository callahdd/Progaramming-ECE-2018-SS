#include <string>
#include <iostream>
#include <cctype>

using namespace std;

int main(){

  string new_string;

  cout << "Is New String Empty? " << ((new_string.empty() >= 1) ? "Yes" : "No") << endl;
  //for(int i = 0; i < 26; i++){
   // new_string[i] = 'a' + i;
  //}
 // cout << "Is New String Empty? " << ((new_string.empty() >= 1) ? "Yes" : "No") << endl;
  //if(!new_string.empty())
  //	cout << "New String: " << new_string << endl;

  for(int i = 0; i < 26; i++){
    new_string += ('a' + i);
  }
  cout << "Is New String Empty? " << ((new_string.empty() >= 1) ? "Yes" : "No") << endl;
  if(!new_string.empty())
  	cout << "New String: " << new_string << endl;

  for(int i = 0; i < new_string.length(); i++){
   new_string[i] = 'A' + i;
  }

  cout << "Is New String Empty? " << ((new_string.empty() >= 1) ? "Yes" : "No") << endl;
  if(!new_string.empty())
  	cout << "New String: " << new_string << endl;

  for(int i = 0; i < 26; i++){
    new_string += 'a' + i;
  }
  cout << "Is New String Empty? " << ((new_string.empty() >= 1) ? "Yes" : "No") << endl;
  if(!new_string.empty())
  	cout << "New String: " << new_string << endl;

  /*for(int i = 0; i < new_string.length(); i++){
   cout << new_string[i] << endl;
  }

  for(int i = 0; i < new_string.length(); i++){
   cout << new_string.at(i) << endl;
  }
*/

  new_string += "bob" ;
  cout << "Is New String Empty? " << ((new_string.empty() >= 1) ? "Yes" : "No") << endl;
  if(!new_string.empty())
  	cout << "New String: " << new_string << endl;

  new_string += int(2) ;
  cout << "Is New String Empty? " << ((new_string.empty() >= 1) ? "Yes" : "No") << endl;
  if(!new_string.empty())
  	cout << "New String: " << new_string << endl;



  return 0;
}
