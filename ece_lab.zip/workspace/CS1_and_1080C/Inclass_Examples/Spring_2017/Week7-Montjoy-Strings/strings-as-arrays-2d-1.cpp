#include <string>
#include <iostream>
#include <cctype>

using namespace std;

int main(){

  string a = "abc";

  string b[] = {"abc2", "cba!", "9zyz"};

  int alpha = 0;
  for(int r = 0; r < 3; r++) {
	string temp = b[r];
	for( int c = 0; c < temp.length(); c++) {
		cout << temp[c] << endl;
	}
	
  }
  for(int r = 0; r < 3; r++) {
	for( int c = 0; c < b[r].length(); c++) {
		cout << b[r][c] << endl;
	}
	
  }


}
