#include <iostream>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <cmath>

using namespace std;

class cubeMulti {
public:
   cubeMulti() {
   }
   cubeMulti(string filename) {
  	if(!readCubeData(filename)){ 
		cout << "Could Not Read" << endl;
		exit(0);
	}
	processList();
		
   }
   void displayList() {
      for(int i = 0; i < cubeList.size(); i++) {
	cout << "a = " << cubeList[i] << " SA = "
	     << surface_area[i] << " volume = "
	     << volume[i] << endl;
      }
   }

private:
  bool readCubeData(string cubelist){

 	ifstream myFile;
        //Link the input file to this object;
        myFile.open(cubelist.c_str());

        if(!myFile) return false;

  	double temp;
        while(!myFile.eof()){
            myFile >> temp;
            cubeList.push_back(temp);
        }

        myFile.close();

        return true;
  }
  void processList() {
      surface_area.clear();
      volume.clear();
      for(int i = 0; i < cubeList.size(); i++) {
	double vol = pow(cubeList[i],3.0);
	double sa = 6*pow(cubeList[i],2.0);
        surface_area.push_back(sa);
        volume.push_back(vol);
      }
	
  }

  vector <double> cubeList;
  vector <double> surface_area;
  vector <double> volume;

};


int main() {

   string cube_list = "cubes.txt";
   cubeMulti c1(cube_list);

   c1.displayList();
}
