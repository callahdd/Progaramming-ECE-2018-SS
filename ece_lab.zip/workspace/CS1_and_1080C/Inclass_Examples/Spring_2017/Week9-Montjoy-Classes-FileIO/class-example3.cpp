#include <iostream>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <cmath>

using namespace std;

struct cubeData {
   double a;
   double sa;
   double vol;
};

class cubeMulti {
public:
   cubeMulti() {
   }
   cubeMulti(string filename) {
  	if(!readCubeData(filename)){ 
		cout << "Could Not Read" << endl;
		exit(0);
	}
	processList();
//	displayList();
		
   }
   void displayList() {
      for(int i = 0; i < cubeList.size(); i++) {
	cout << "a = " << cubeList[i].a << " SA = "
	 	<< cubeList[i].sa << " Vol = "
	     << cubeList[i].vol << endl;
      }
   }

private:
  bool readCubeData(string cubelist){

 	ifstream myFile;
        //Link the input file to this object;
        myFile.open(cubelist.c_str());

        if(!myFile) return false;

  	cubeData temp;
        while(!myFile.eof()){
            myFile >> temp.a;
            cubeList.push_back(temp);
        }

        myFile.close();

        return true;
  }

  void processList() {
      for(int i = 0; i < cubeList.size(); i++) {
	double vol = pow(cubeList[i].a,3.0);
	double sa = 6*pow(cubeList[i].a,2.0);
	
        cubeList[i].vol = vol;
        cubeList[i].sa = sa;
      }
	
  }

  vector <cubeData> cubeList;

};


int main() {

   string cube_list = "cubes.txt";
   cubeMulti c1(cube_list);

   c1.displayList();
}
