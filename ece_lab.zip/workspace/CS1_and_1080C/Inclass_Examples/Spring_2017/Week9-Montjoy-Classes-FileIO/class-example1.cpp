#include <iostream>

using namespace std;

class cube {
public:
   // Make a 1 by 1 by 1 cube by default
   cube() {
      a = 1;
      update();
   }
   cube(double in_a) {
      a = in_a;
      update();
   }
   ~cube(){
     cout  << "Object Destroyed" << endl;
   }
   void print(){
	cout << "a = " << a << endl;
	cout << "SA = " << surface_area << endl;
	cout << "V = " << volume << endl;
   }
   void seta(double in_a) { a = in_a; update(); }
   double geta() { return a; }
   double getSA() { return surface_area; }
   double getV() { return volume; }
private:
  void update() {
      surface_area = 6*a*a;
      volume = a*a*a;
  }

  double a;
  double surface_area;
  double volume;

};


int main() {

   cube c0;
   //cube c2();
   cube c1(8);

   c0.print();
   c0.seta(2);
   c0.print();
   c1.print();
}
