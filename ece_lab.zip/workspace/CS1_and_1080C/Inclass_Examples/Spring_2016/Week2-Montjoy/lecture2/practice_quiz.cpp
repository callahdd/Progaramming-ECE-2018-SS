// Author: Rob Montjoy
// Description: Practice Quiz2

#include <iostream>
#include <string>

using namespace std;

int main(){
  cout << 8 * 8 + 7 * 7 << endl;
  cout << 8 + 8 * 7 + 7 << endl;
  cout << 9 / 8 + 8 / 9 << endl;
  cout << 15 / 4 << endl;
  cout << 15 /4 * 2 << endl;
  cout << 15.0 / 4 * 2 << endl;
  
  return 0;
}
