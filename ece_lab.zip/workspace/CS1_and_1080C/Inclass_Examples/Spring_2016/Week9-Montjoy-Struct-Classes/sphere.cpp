// Name:
//
// Problem 2: Class Sphere	 - 50-Points 
// 
// Notes: A Sphere can be defined in terms of its radius or diameter.
// 
//	  Surface Area of a sphere is 4 PI (Radius X Radius)
//	  Volume of a sphere is 4/3 PI (Radius X Radius X Radius)
//	  

#include <cmath>
#include <iostream>
#include <iomanip>

using namespace std;

const double PI =  3.14159265358979323846;

// Fully implement the following class

class Sphere
{
	public:
		Sphere();			// default constructor
		Sphere(double);			// double is the Radius
		void SetSphere(double);		// double is the Radius,
						// Should set volume, and area
						// too.
		double GetRadius();		// Return the Radius
		double SurfaceArea();		// Calculates the SufaceArea
		double Volume();			// Calculates the Volume
		void PrintSphere();		// Prints Information about 
	private:
		double radius;
		double volume;
		double surfacearea;
		
};

Sphere::Sphere()
{
	SetSphere(1.0);
}

Sphere::Sphere(double r)
{
	SetSphere(r);
}

void Sphere::SetSphere(double r)
{
	radius = r;
	surfacearea = 4.0*PI*radius*radius;
	volume 	    = 4.0/3.0*PI*radius*radius*radius;
}

double Sphere::GetRadius()
{
	return radius;
}

double Sphere::SurfaceArea()
{
	return surfacearea;
}

double Sphere::Volume()
{
	return volume;
}

void Sphere::PrintSphere()
{
	cout << radius << endl;
	cout << volume << endl;
	cout << surfacearea << endl;
}


int main() {
	Sphere S1(2), S2, S3(5);


	S1.PrintSphere();
	S2.PrintSphere();
	S3.PrintSphere();
	S3.SetSphere(6);
	S3.PrintSphere();

	return 0;
}

