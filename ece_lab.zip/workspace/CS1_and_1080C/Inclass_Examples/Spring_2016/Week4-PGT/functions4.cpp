#include <iostream>
#include <string>

using namespace std;

int counter = 2;
int getSum(int thing2){
	int counter = 0;
	counter++;
	return counter + thing2;
}


int main(){
	cout << getSum(1) << endl;
	cout << getSum(1) << endl;
	cout << getSum(1) << endl;
	cout << counter << endl;
	return 0;
}


