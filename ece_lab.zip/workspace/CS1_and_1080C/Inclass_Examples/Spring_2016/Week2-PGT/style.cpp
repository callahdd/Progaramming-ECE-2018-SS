#include <iostream>

using namespace std;

const float PI = 3.1415; 

void dumbFunction(){

}

int main(){

  int b = 6;
  int c = 10;
  
  int this_is_a_long_variable;
 
  if(stuff){
    lots of stuff in here
  }
 
  if(b == c){ 
    cout << "the same!\n";
    cout << "the same again\n";
  }else{
    cout << "not the same!\n";
  }
  
/*  Don't do this
  if(b == c)
    cout << "the same!\n";
    cout << "This is something else\n";
  else
    cout << "not the same!\n";
*/ 
    
  return 0;
}
