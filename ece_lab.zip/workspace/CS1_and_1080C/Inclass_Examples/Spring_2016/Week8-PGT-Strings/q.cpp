#include <iostream>
#include <string>
#include <cstring>

using namespace std;


int main(){
	char a[5];

	a[0] = ' ';

	cout << strlen(a) << endl;
  
  return 0;
}
