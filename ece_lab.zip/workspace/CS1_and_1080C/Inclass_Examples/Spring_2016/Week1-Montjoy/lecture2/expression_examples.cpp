
// 

#include <iostream>

using namespace std;

int main(){
  cout << "4/3 + 3 * 5 = " <<  4/3 + 3 * 5 << endl << endl;
  cout << "3/4 + 5 * 4 = " << 3/4 + 5 * 4 << endl << endl;
  cout << "3/(4 + 5) * 4 = " << 3/(4 + 5) * 4 << endl << endl;
  cout << "4 + 4 * 4 / 3 = " << 4 + 4 * 4 / 3 << endl << endl;
  cout << "4./3. + 5 * 6 = " << 4./3. + 5 * 6 << endl << endl;
  cout << "(4 * 1 + 5)/10 = " << (4 * 1 + 5)/10 << endl << endl;
  cout << "(4 * 1 + 5)/10.0 = " << (4 * 1 + 5)/10.0 << endl << endl;
  return 0;
}
