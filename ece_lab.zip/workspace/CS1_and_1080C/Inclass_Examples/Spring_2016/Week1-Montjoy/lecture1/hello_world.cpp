// Author: Rob Montjoy
// Source File: hello_world.cpp

#include <iostream>

using namespace std;

int main()
{
  cout << "Hello World!" << endl;
  
  return 0;
}

