#include <iostream>
#include <string>

using namespace std;

int main(){
  
  string a = "This is a test";    // The C++ way to do strings
  const char* b = "This is another test\n"; // The C way to do strings
  
  
  cout << a << endl;
  cout << b << endl;
  
}
