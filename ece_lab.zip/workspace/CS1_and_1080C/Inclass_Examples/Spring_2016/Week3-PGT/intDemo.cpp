#include <iostream>

using namespace std;

int main(){
  int a;
  
  cout << "a: " << a << endl;// EEk, random data!
  // Be sure to always initialize variables.
}
