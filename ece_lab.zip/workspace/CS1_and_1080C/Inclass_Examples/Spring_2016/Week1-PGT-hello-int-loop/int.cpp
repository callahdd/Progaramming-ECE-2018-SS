#include <iostream>

using namespace std;

int main(){
  
  int number = 0;
  while(1){
    cout << "Number: " << number << endl;
    number = number + 100000;
  }
  return 0;
}
