#include <iostream>

using namespace std;

int main(){
  // This is a one line comment
  
  cout << "long long int: " << sizeof(long long int) << endl;
  cout << "short int: " << sizeof(short int) << endl;
  cout << "float: " << sizeof(float) << endl;
  cout << "double: " << sizeof(double) << endl;
  return 0;
}
