#include <iostream>

using namespace std;

int main(){
  // This is a one line comment
  int a = 5;
  int b = 7;
  
  cout << "a/b: " << a/b << endl;
  cout << "b/a: " << b/a << endl;
  return 0;
}
