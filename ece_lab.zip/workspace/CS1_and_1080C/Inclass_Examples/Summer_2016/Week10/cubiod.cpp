#include <iostream>

using namespace std;

class Cubiod
{
public:
    Cubiod()
    {
        width = 0;
        height = 0;
        length = 0;
     	updateParameters();
    }

    Cubiod(double in_w, double in_h, double in_l)
    {
        setWidth(in_w);
        setHeight(in_h);
        setLength(in_l);
     	updateParameters();
    }

    void setWidth(double in_w)
    {
        width = in_w;
     	updateParameters();
    }

    void setHeight(double in_h)
    {
        height = in_h;
     	updateParameters();
    }

    void setLength(double in_l)
    {
        length = in_l;
     	updateParameters();
    }

    double getWidth()
    {
        return width;
    }

    double getLength()
    {
        return length;
    }

    double getHeight()
    {
        return height;
    }

    double getVolume()
    {
        return volume;
    }

    double getSurfaceArea()
    {
        return surfaceArea;
    }

    void print()
    {
        cout << "Our Cubiod has the following stats:" << endl;
        cout << "Height: " << height << endl;
        cout << "Length: " << length << endl;
        cout << "Width: "  << width  << endl;
        cout << "Surface Area: "  << surfaceArea  << endl;
        cout << "Volume: "  << volume  << endl;
    }
private:
    void updateParameters()
    {
	surfaceArea = 2 * width * length + 2*length*width + 2 * height * width;
	volume = length * width * height;
    }
    double width, length, height;
    double surfaceArea, volume;
};

int main()
{
    Cubiod A1;
    //Cubiod A1();
    Cubiod B1(24,55,66);

    A1.print();
    B1.print();

    A1.setWidth(2);
    A1.setHeight(2);
    A1.setLength(2);
    A1.print();
    cout << "Width of Cubiod: " << A1.getWidth() << endl;

    return 0;
}

