#include <iostream>
#include <string>

using namespace std;

class Animal
{
private:
    double width, length, height;
    string color;
    void SomeFunction();
public:
    Animal()
    {
        width = 0;
        height = 0;
        length = 0;
        color = "";
    }

    Animal(double in_w, double in_h, double in_l, string in_color)
    {
        width = in_w;
        height = in_h;
        length = in_l;
        color = in_color;
    }

    void setWidth(double in_w)
    {
        width = in_w;
	SomeFunction();
    }

    void setHeight(double in_h)
    {
        height = in_h;
    }

    void setLength(double in_l)
    {
        length = in_l;
    }

    void setColor(string in_c)
    {
        color = in_c;
    }

    double getWidth()
    {
        return width;
    }

    double getLength()
    {
        return length;
    }

    double getHeight()
    {
        return height;
    }

    string getColor()
    {
        return color;
    }

    void print()
    {
        cout << "Our Animal has the following stats:" << endl;
        cout << "Height: " << height << endl;
        cout << "Length: " << length << endl;
        cout << "Width: "  << width  << endl;
        cout << "Color: "  << color << endl;
    }
};

void Animal::SomeFunction() {}

int main()
{
    Animal A1;
    Animal B1(24,55,66,"purple");

    // A1.SomeFunction();
    A1.print();
    B1.print();

    A1.setColor("red");
    A1.print();
    cout << "Color of Animal: " << A1.getColor() << endl;

    return 0;
}

