
#include <iostream>
#include <complex>
using namespace std;


// Just add two complex numbers and a floating number (real)
complex<double> doAdd(complex<double> X, complex<double> Y)
{
    return X + Y + 1.0;
}

// Difference between the magitude of X and Y
// good to show how to check coverengce
double absDifference(complex<double> X, complex<double> Y)
{
    return abs(X - Y);
}

int main()
{
    // Declare two complex numbers
    complex<double> X(5,10), Y(6, 8);
    cout << doAdd(X, Y) << endl;
    //

    // Normal complex number add. No need to call functions
    complex<double> Z = X + Y + 1.0;

    cout << Z.real() << " + j" << Z.imag() << endl;

    cout << absDifference(X, Y) << endl;

    // int's are not constructor overloaded so you have to do the following
    // instead:

    cout << X + Y + complex<double>(1) << endl;

    return 0;
}

// Sample complex number math
//complex<double> A(5.,5.), B(5.,5.);
//cout << A - B << endl;
