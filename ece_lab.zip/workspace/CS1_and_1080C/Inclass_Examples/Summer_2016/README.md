All Examples for Summer 2016 are from Rob Montjoy

Week1: C++ Introduction

Week2: Decision Statements (if/else),  and Basic Formating

Week3: Table Formatting, Decision Statements (switch/case), and 
       overflowing intgers

Week4: Functions

Week5: Functions and Arrays

Week6: More Functions

Week7: C++ Strings,  vectors, and C/C++ style 2d arrays

Week8: More C++ Strings,  and C++ vectors. Plus C style strings and 
	 a very basic introduction to classes (objects).

Week 10: More class demos

Week 11: Pointers and Structures
