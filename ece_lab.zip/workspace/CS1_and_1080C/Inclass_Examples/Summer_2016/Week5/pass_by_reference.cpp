#include <iostream>

using namespace std;

void X(int &x, int y)
{
    x = y*y;
}

int Z(int a, int b, int c)
{
    return a * b * c;
}

int XZ(int a, int b, int c, int &x)
{
    x = c*c;
    return a * b * c;

}

int XZREF(int &a, int b, int c, int &x)
{
    x = c*c;
   cout << "a: " << a << " x: " << x << endl;
    return a * b * c;

}
int main()
{
    int x = 4;
    int y = 7;
    int xx = x;
    int yy = y;

    cout << x << endl;
  //  int z = 9;

    X(x,y);
    cout << x << "  " << y << endl;
    cout << Z(x,xx,yy) << endl;
    cout << XZ(x,xx,yy, y) << endl;
    cout << y << endl;
    cout << XZ(x,xx,yy, x) << endl;

    cout << x << endl;
    x = 9;
    cout << XZREF(x,xx,yy, x) << endl;

    cout << x << endl;
    return 0;
}
