#include <iostream>
#include <cstdlib>

using namespace std;

int main(int argc, char *argv[]){
    int arrayt[22222222]={};

    cout << "He"
         << "llo World!" << "sdf" << endl;
  cout << arrayt[5] << endl;
  arrayt[5] = 345345;
  cout << arrayt[5] << endl;
  for(int k = 0; k < 1000000; k++){
      arrayt[k] = rand()%55;
  }
  for(int i = 0; i < 1000000; i++)
      cout << arrayt[i] << endl;

    return 0;
}
