#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main(int argc, char *argv[])
{
    srand(time(0));
    cout << "Hello World!" << endl;
    char string[500] = {0};

    for (int i = 0; i < rand()%50; i++)
        string[i] = 'a' + rand()%26;
    cout << string << endl;
    return 0;
}
