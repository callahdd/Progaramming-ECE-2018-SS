#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int sumofArray(int array[][10], int row_length, int column_length)
{
    //cout << "Sum " << sizeof(array)/sizeof(int)<< endl;
   int sum = 0;

   for(int row = 0; row < row_length; row++)
   {
       for(int column = 0; column < column_length; column++)
       {
            sum += array[row][column];
       }
   }


   return sum;
}
int main()
{
    srand(time(0));

    static int arrayName[5][10] = {};

    //int *arrayName = new int[51];

    for(int i = 0; i < 200000; i++)
        arrayName[rand()%5][rand()%10] += 1;

    cout << arrayName << endl;
    cout << &arrayName[1] << endl;
    //return 0;

    for(int row = 0; row < 5; row++)
    {
        for(int column = 0; column < 10; column++)
        {
            cout << row << "," << column << "\t"
                 << arrayName[row][column] << endl;
        //cout << "address of " << &arrayName[i] << endl;
        }
    }

    cout <<  sumofArray(arrayName, 5, 10) << endl;


    return 0;
}
