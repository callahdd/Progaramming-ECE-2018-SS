#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int sumofArray(int array[], int length)
{
    //cout << "Sum " << sizeof(array)/sizeof(int)<< endl;
   int sum = 0;

   for(int i = 0; i < length; i++)
       sum += array[i];

   return sum;
}

void scaleArray(int array[], int length, int scaler)
{

   for(int i = 0; i < length; i++)
       array[i] *= scaler;
       //array[i] = array[i] * scaler;

}

void displayArray(const int array[], int length)
{
    for(int i = 0; i < length; i++)
    {
        cout << i << "\t" << array[i] << endl;
    }
}

int main()
{
    srand(time(0));

    const int length = 51;
    int arrayName[length] = {};

    //int *arrayName = new int[51];

    for(int i = 0; i < 1000000; i++)
        arrayName[rand()%51] += 1;

    cout << arrayName << endl;
    cout << &arrayName[1] << endl;
    cout << sumofArray(arrayName, sizeof(arrayName)/sizeof(int)) << endl;
    displayArray(arrayName, length);
    scaleArray(arrayName, length, 4);
    displayArray(arrayName, length);
    cout << sumofArray(arrayName, sizeof(arrayName)/sizeof(int)) << endl;
    return 0;

    for(int i = 0; i <= 50; i++)
    {
        cout << i << "\t" << arrayName[i] << endl;
        cout << "address of " << &arrayName[i] << endl;

    }

    cout << sumofArray(arrayName, sizeof(arrayName)/sizeof(int)) << endl;
    cout << sumofArray(&arrayName[51-2], 2) << endl;

    return 0;
}
