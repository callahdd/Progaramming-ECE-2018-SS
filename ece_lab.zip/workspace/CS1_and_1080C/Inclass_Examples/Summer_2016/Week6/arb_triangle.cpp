#include <iostream>
#include <cmath>

using namespace std;

bool arbitraryTriangleArea(double n1, double n2, double n3,
                           double& a, double& per)
{
  a = -1;
  per = -1;
  if(n1 + n2 < n3)return false;
  if(n2 + n3 < n1)return false;
  if(n1 + n3 < n2)return false;

  per = n1 + n2 + n3;

  double s = (n1 + n2 + n3)/2;
  a = sqrt(s * (s-n1) * (s-n2) * (s-n3));
  return true;
}

int main(){

  double n1, n2, n3, area, perimeter;
  cout << "Enter 3 numbers";
  cin >> n1;
  cin >> n2;
  cin >> n3;
  if(arbitraryTriangleArea(n1, n2, n3, area, perimeter))
  {
    cout << "Area: " << area << endl;
    cout << "Perimeter: " << perimeter << endl;
  }
  else
  {
      cout << "Not a triangle" << endl;
      cout << "Area: " << area << endl;
      cout << "Perimeter: " << perimeter << endl;
  }

  return 0;
}
