int enough(int goal){
    int i = 0;
    int sum = 0;
    while(sum <= goal){
        i++;
        sum += i;
    }
    return --i;
}

int enough2(int number)
{
    int i = 0;
    int sum = 0;
    while(sum < number){
        sum += i;
        i++;
    }
    if(sum == number){
        return i - 1;
    }
    return i - 2;
}

int main(){

    int x;
    cout << "Enter a number";
    cin >> x;
    cout << "Enough: " << enough(x) << endl;
    cout << "Enough: " << enough2(x) << endl;

    return 0;
}
