// Basic If/Else statements

#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int x = 2;


    if(x) // x != 0
    {
       cout << x << "\n";
    }
    else
    {
        cout << "88" << endl;
        cout << "!=2\t" << x << endl;
    }

    x = 0;
    if(!x)
        cout << "sdfsdf0" << endl;

    int y = 2;

    if(x == 0)
    {

    }
    else if(y == 3)
    {

    }
    else if(x == 2 && y == 3)
    {
    }
    else if(x == 2 || y == 3)
    {
    }
    else
    {
    }
    cout << "Hello World!" << endl;
    return 0;
}
