// Some basic iomanip commands

#include <iostream>
#include <cmath>
#include <iomanip>

const double PI = atan(1.0)*4;

using namespace std;

int main(int argc, char *argv[])
{
    double angle = 45*PI/180;

    cout << fixed << setw(8) << showpoint << setprecision(3)
         << angle << setw(6) << sin(angle);
    cout << endl;

    return 0;
}
