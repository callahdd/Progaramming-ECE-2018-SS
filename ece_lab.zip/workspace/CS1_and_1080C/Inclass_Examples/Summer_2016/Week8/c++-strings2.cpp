

#include <iostream>
#include <string>
#include <cctype>

using namespace std;

int main()
{

  string x = "sdfsDfsDF";

  for(int i = 0; i < x.length();i++){
	cout << x[i] ;
  }
  cout << endl;
  int ucsum = 0;
  for(int i = 0; i < x.length();i++){
	if(isupper(x[i])) 
          ucsum++;
  }
  cout << "UPPERCASE: " << ucsum << endl;
  for(int i = 0; i < x.length();i++){
	cout << x[i] ;
  }
  cout << endl;
   
  return 0;
}
