#include <iostream>
#include <vector>
#include <cstdlib>

const int ARRAY_MAX_SIZE = 500;
const int ARRAY_INITIAL_SIZE = 10;
using namespace std;


int main()
{
	vector<int> v_array(ARRAY_INITIAL_SIZE,10);

	cout << "Output using standard array method" << endl;
	for(int i = 0; i < v_array.size(); i++)
		cout << v_array[i] << endl;


	cout << "Output using at() method" << endl;
	for(int i = 0; i  < v_array.size(); i++)
		cout << v_array.at(i) << endl;

	cout << "Resize Array to 5 elements" << endl;
	v_array.resize(5);

	cout << "Output using at() method" << endl;
	for(int i = 0; i  < v_array.size(); i++)
		cout << v_array.at(i) << endl;

        cout << "Call push_back" << endl;
	v_array.push_back(rand()%5);
	v_array.push_back(rand()%5);
	v_array.push_back(rand()%5);
	v_array.push_back(rand()%5);
	v_array.push_back(rand()%5);
	v_array.push_back(rand()%5);
	cout << "Output using standard array method" << endl;
	for(int i = 0; i < v_array.size(); i++)
		cout << v_array[i] << endl;

	return 0;
}


