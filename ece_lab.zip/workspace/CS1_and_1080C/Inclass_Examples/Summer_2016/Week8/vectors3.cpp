#include <iostream>
#include <vector>
#include <cstdlib>

const int ARRAY_MAX_SIZE = 500;
const int ARRAY_INITIAL_SIZE = 10;
using namespace std;



void VectorScale(vector <int> &x, int scale)
{
	for(int i = 0; i < x.size(); i++)
		x[i] = x[i] * scale;
}

vector<int> VectorGen(int size)
{
	vector<int> x;
	for(int i = 0; i < size; i++)
		x.insert(x.end(), 1, rand()%size);
	
	return x;
}


void DisplayVector( vector<int> const &display_me)
{
	for(vector<int>::const_iterator it = display_me.begin(); 
		it != display_me.end(); it++)
	{
		cout << *it << endl;
	}
}


int main()
{
	srand(time(0));
	vector<int> v_array;

 	cout << "Org Random Array" << endl;
	v_array = VectorGen(5);
 	DisplayVector(v_array);
 	cout << "Scale Array by 2" << endl;
	VectorScale(v_array, 2);
 	DisplayVector(v_array);
		
	return 0;
}


