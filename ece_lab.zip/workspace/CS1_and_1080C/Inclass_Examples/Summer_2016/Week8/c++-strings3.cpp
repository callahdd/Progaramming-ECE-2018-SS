

#include <iostream>
#include <string>
#include <cctype>

using namespace std;

int main()
{

  string x;
  x += 'a';

  for(int i = 0; i < x.length();i++){
	cout << x[i] ;
  }
  cout << endl;
  x  = "";
  x[0]='b';
  cout << x << endl;
   
  return 0;
}
