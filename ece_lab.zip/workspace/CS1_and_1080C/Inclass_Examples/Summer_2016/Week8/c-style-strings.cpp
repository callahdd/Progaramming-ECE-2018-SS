
// Demo of standard C style strings

#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

int main()
{
  char c_string1[] = "Hello World";
  char c_string2[200];
  char c_string3[200];

  cout << strlen(c_string1) << endl;
  c_string2[0] = '\0';  // same as 0
  strcpy(c_string2,"");
  strcat(c_string2, "abc");
  strcat(c_string2, "123");
  cout << c_string2 << endl;
  strcpy(c_string2, c_string1);
  cout << c_string2 << endl;

  for(unsigned int i = 0; i < strlen(c_string2); i++)
	cout << c_string2[i];

  // tolower returns an int and needs to be cast to 
  // a unsigned char for display purposes
  for(unsigned int i = 0; c_string2[i] != 0 ; i++)
	cout << (unsigned char)tolower(c_string2[i]);
  cout << endl;


  strcpy(c_string3,"");
  for(unsigned int i = 0; c_string2[i] != 0 ; i++)
	c_string3[i] = tolower(c_string2[i]);
  c_string3[strlen(c_string2)] = 0;
  cout << c_string3 << endl;
  // ispunct or isspace and tolower


  return 0;
}
