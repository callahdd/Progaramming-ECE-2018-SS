// Name: Paul Talaga - Solution!
// Laboratory 1:  Part C
// Source File: grade.cpp

#include <iostream>
#include <cmath>

using namespace std;

int main(){
        double h1, h2, h3;  // 25% of final grade
        double t1, t2, t3;      // 50% of final grade
        double final_exam;  // 25% of final grade
        double final_project;

        cout << "Homework 1 grade:";
        cin  >> h1;
        cout << "Homework 2 grade:";
        cin  >> h2;
        cout << "Homework 3 grade:";
        cin  >> h3;
        cout << "Test 1 grade:";
        cin  >> t1;
        cout << "Test 2 grade:";
        cin  >> t2;
        cout << "Test 3 grade:";
        cin  >> t3;
        cout << "Final Exam grade:";
        cin  >> final_exam;
        cout << "Final Project:";
        cin  >> final_project;

        double homework = (h1+h2+h3)/3.0;
        double tests = (t1 + t2  + t3) / 3.0;
        double grade = homework * 0.25 + tests * 0.3 + final_exam * 0.25 + final_project*.20;
        cout    << "Final grade: "
                << grade
                << endl;

        return 0;
}


