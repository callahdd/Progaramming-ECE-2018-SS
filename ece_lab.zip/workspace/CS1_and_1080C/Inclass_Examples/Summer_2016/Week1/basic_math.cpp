//  Author: Rob Montjoy
// Description: Math Demo

#include <iostream>
#include <string>

using namespace std;

int main()
{
    double j = 2;
    int k = 3;
    int p;

    // this should print an unknown value
    cout << p << endl;

    cout << j/k << endl;

    cout << k/j << endl;

    // Simple assignment statement
    p = 6;
    // C Style cast
    cout << (double)p/k << endl;

    p = 11;
    // C++ Style Cast
    cout << static_cast<double>(p)/k << endl;

    // Some precedence equations
    cout << k + j/k + p * 7 << endl;

    return 0;
}
