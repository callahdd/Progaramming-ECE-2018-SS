//  Author: Rob
// Description: Hello Bill

#include <iostream>
#include <string>

using namespace std;

int main()
{
    cout << "Enter Name:";
    string bill;
    cin >> bill;

    cout << "Hello " << bill << endl ;

    return 0;
}
