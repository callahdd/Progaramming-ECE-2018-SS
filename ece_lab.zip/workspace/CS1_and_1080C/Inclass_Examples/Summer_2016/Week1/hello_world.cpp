// Single line comment (comment to end of line)
//  Author: Rob
// Description: Hello World
/* I am a multiline comment
 * line 2
 * line 3
 *
 */

#include <iostream>
#include <string>

using namespace std;

int main()
{
    cout << "Hello World" << endl;	// cout displays ascii text
    return 0;
}
