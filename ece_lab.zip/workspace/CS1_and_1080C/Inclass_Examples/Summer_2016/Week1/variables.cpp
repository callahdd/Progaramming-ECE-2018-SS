#include <iostream>
#include <string>

using namespace std;

int main()
{
    string xyz = "bill";
    unsigned char ascii1 = 'A'; // 8 bits
    signed short var0 = 0;
    int var1 = 0;
    long var2 = 0;
    long long var3 = 0; // 128bits

    float varf1 = 0.0;
    double vard1 = 0.0;
    long double varld1 = 0.0; //12 bytes

    cout << static_cast<int>(ascii1) << endl;

    cout << sizeof(varf1) << endl;
    cout << sizeof(varld1) << endl;

    double double_result;
    int int_result;

    cout << int_result << endl;
    cout << double_result << endl;

    int_result = 5/6 + 6*9 - 19/10;
    cout << int_result << endl;
    int_result = 5/6. + 6*9 - 19./10.;
    cout << int_result << endl;
    double_result = 5/6. + 6*9 - 19./10.;
    cout << double_result << endl;

    int_result = 6 % 2;
    cout << int_result << endl;

    int_result = 5 % 2;
    cout << int_result << endl;

    int_result += 1; // int_result = int_result + 1;
    cout << int_result << endl;

    int_result *= 4;
    cout << int_result << endl;

    int_result++; // increment operator int_result = int_result + 1;
    int_result--; // deccrement operator int_result = int_result - 1;

    ++int_result; // increment operator int_result = int_result + 1;
    --int_result; // deccrement operator int_result = int_result - 1;


    cout << "int++ "  << int_result++ << endl;
    cout << "int-- " << int_result-- << endl;
    cout << "After postfix" << int_result << endl;
    cout << "++int" << ++int_result << endl;
    cout << "--int" << --int_result << endl;


    int_result = ++int_result;

    cout << "Hello World!" << endl;
    return 0;
}
