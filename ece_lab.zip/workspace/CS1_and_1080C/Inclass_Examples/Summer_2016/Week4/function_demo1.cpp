// Demo of functions w/ overloading and pass-by-reference.
// Paul Talaga - CS1 - Spring 2016
#include <iostream>

using namespace std;

int Sum(int a, int b)
{
    return a + b;
}

double average(int sum, int loopcount)
{
    return (double)sum/loopcount;
}

int rangeSum(const int &from , const int &to, int &loop_times)
{
    cout << "address of" << &loop_times << endl;
    cout << "address of to: " << &to << endl;
    int sum = 0;
    loop_times = 0;
    for(int i = from; i <= to; i++)
    {
        sum = Sum(sum, i);
        loop_times++;
        //sum = sum + i;
    }

    return sum;
}

int rangeSum(int from, int to)
{
    int junk;
    cout << "address of" << &junk << endl;
    cout << "address of to: " << &to << endl;

    return rangeSum(from, to, junk);
}

int rangeSum(int to)
{
    // Assume from is 0
    cout << "address of to: " << &to << endl;

    return rangeSum(0, to);
}

int main()
{
    cout << "The sum from 1 to 1 is: " << rangeSum(1,1) << " should be: 1" << endl;
    cout << "The sum from -1 to 1 is: " << rangeSum(-1,1) << " should be: 0" << endl;
    cout << "The sum from 5 to 1 is: " << rangeSum(5,1) << " should be: 0" << endl;
    cout << "The sum from 0 to 100 is: " << rangeSum(100) << " should be: 5050" << endl;

    int loop_t;
    cout << "The sum from 0 to 100 is: " << rangeSum(0, 100, loop_t) << " should be: 0" << endl;
    cout << "I looped " << loop_t << " times.\n";
    cout << "average:" << average(rangeSum(0,100, loop_t), loop_t) << endl;
    cout << "The sum from 5 to 10 is: " << rangeSum(5,10) << endl;
}

