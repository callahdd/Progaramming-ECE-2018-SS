#ifndef STATS_TEST_H
#define STATS_TEST_H

#include <iostream>
#include <cxxtest/TestSuite.h>

#define main do_not_use_me
#include "array_stats.cpp"
#undef main

using namespace std;

// This requires CxxTest to be installed!
// For this CPPVideos example, navigate your terminal to CPPVideos and type:
// git submodule add https://github.com/CxxTest/cxxtest.git
// This will add the public CxxTest repository INSIDE the current repo.
// The current Makefile in this directory assumes cxxtest is a folder one
// level down.


class MyMax : public CxxTest::TestSuite {
public:
  void testMax1() {
    TS_ASSERT_EQUALS(Max(1, 3), 3);
  }
  
  void testMax2() {
    TS_ASSERT_EQUALS(Max(0, 0), 0);
  }
  
  void testMax3() {
    TS_ASSERT_EQUALS(Max( 1 ,1), 1);
  }
  
  void testMax4() {
    TS_ASSERT_EQUALS(Max( 30 ,3), 30);
  }

  void testMax5() {
    TS_ASSERT_EQUALS(Max( -20 , -10), -10);
  }
};

class MyMin : public CxxTest::TestSuite {
public:
  void testMin() {
    TS_ASSERT_EQUALS(Min(1, 3), 1);
  }
  
  void testMin2() {
    TS_ASSERT_EQUALS(Min(0, 0), 0);
  }
  
  void testMin3() {
    TS_ASSERT_EQUALS(Min( 1 ,1), 1);
  }
  
  void testMin4() {
    TS_ASSERT_EQUALS(Min( 30 ,3), 3);
  }

  void testMin5() {
    TS_ASSERT_EQUALS(Min( -20 , -10), -20);
  }
};

class MySum : public CxxTest::TestSuite {
public:
  void testSum1() {
    int a[] = {1,2,3};
    TS_ASSERT_EQUALS(arraySum(a, 3), 6);
  }
  
  void testSum2() {
    int a[] = {};
    TS_ASSERT_EQUALS(arraySum(a, 0), 0);
  }
  
  void testSum4() {
    int a[] = {-5,5,-10, 10};
    TS_ASSERT_EQUALS(arraySum( a ,4), 0);
  }
  
  void testSum5() {
    int a[] = {10,20,30};
    TS_ASSERT_EQUALS(arraySum( a ,3), 60);
  }
};

class MyMean : public CxxTest::TestSuite {
public:
  void testSum1() {
    int a[] = {1,2,3};
    TS_ASSERT_DELTA(arrayMean(a, 3), 2, 0.0001);
  }
  
  void testSum2() {
    int a[] = {};
    TS_ASSERT_DELTA(arrayMean(a, 0), 0, 0.0001);
  }
  
  void testSum4() {
    int a[] = {-5,5,-10, 10};
    TS_ASSERT_DELTA(arrayMean( a ,4), 0, 0.0001);
  }
  
  void testSum5() {
    int a[] = {10,20,30};
    TS_ASSERT_DELTA(arrayMean( a ,3), 20, 0.0001);
  }
};

class MyMinArray : public CxxTest::TestSuite {
public:
  void testSum1() {
    int a[] = {1,2,3};
    TS_ASSERT_EQUALS(arrayMin(a, 3), 1);
  }
  
  void testSum2() {
    int a[] = {};
    TS_ASSERT_EQUALS(arrayMin(a, 0), 0);
  }
  
  void testSum4() {
    int a[] = {-5,5,-10,10};
    TS_ASSERT_EQUALS(arrayMin( a ,4), -10);
  }
  
  void testSum5() {
    int a[] = {10,20,30};
    TS_ASSERT_EQUALS(arrayMin( a ,3), 10);
  }
};

class MyMaxArray : public CxxTest::TestSuite {
public:
  void testSum1() {
    int a[] = {1,2,3};
    TS_ASSERT_EQUALS(arrayMax(a, 3), 3);
  }
  
  void testSum2() {
    int a[] = {};
    TS_ASSERT_EQUALS(arrayMax(a, 0), 0);
  }
  
  void testSum4() {
    int a[] = {-5,5,-10,10};
    TS_ASSERT_EQUALS(arrayMax( a ,4), 10);
  }
  
  void testSum5() {
    int a[] = {10,20,30};
    TS_ASSERT_EQUALS(arrayMax( a ,3), 30);
  }
};

class MyStDev : public CxxTest::TestSuite {
public:
  void testSum1() {
    int a[] = {1,2,3};
    TS_ASSERT_DELTA(arrayStdDev(a, 3), 0.8164, 0.0001);
  }
  
  void testSum2() {
    int a[] = {};
    TS_ASSERT_DELTA(arrayStdDev(a, 0), 0, 0.0001);
  }
  
  void testSum4() {
    int a[] = {-5,5,-10,10};
    TS_ASSERT_DELTA(arrayStdDev( a ,4), 7.9056, 0.0001);
  }
  
  void testSum5() {
    int a[] = {10,20,30};
    TS_ASSERT_DELTA(arrayStdDev( a ,3), 8.1649, 0.0001);
  }
};




#endif
