
// Pointers part 3
#include <iostream>

using namespace std;

int main(){


  // Uncomment this block if you want to see the program
  // crash
  /*
  int *bob = NULL;
  
  cout << *bob << endl;
  return 0;
  */
  
  
  /*

  // Another way of crashing - Memory leak demo
  // It takes a long time to allocate this much memory
  // This may actually lock up your computer
  int *bob2;
  for(unsigned i = 0; i < 100000000; i++){
     bob2 = new int;
     *bob2 = 45;
     // Free up memory just allocated
     //delete bob2;
     //bob2 = NULL;
     // Uncomment this if you want to see it crash
     // cout << *bob2 << endl;
  }
  */

  /*
  // This will not compile
  int *bob3 = 5;
  cout << *bob3 << "-" << bob3 << endl;
  */
  
  // You need to do this instead
  int bobby;
  int *bob3 = &bobby;
  bobby = 6;
  cout << *bob3 << "-" << bob3 << endl;

  
  // Pointers to Pointers
  int x = 5;
  int** bob = new int*;
  *bob = &x;

  cout << x << "-" << *bob << "-" << **bob << endl;
  
  
  // Pointers to Pointers to Pointers
  int** bob9 = new int*;
  *bob9 = new int;
  **bob9 = 94;
  
  cout << bob9 << "-" << *bob9 <<"-" << **bob9 << endl;
  
  
  // Void pointers and casting
  void** vbob = new void*;
  *vbob = (void*)(new int);
  
  *(int*)(*vbob) = 5;
  
  return 0;
}
