
#include <iostream>

using namespace std;


void A(int *p, int w, int t )
{
	if(w > t)
		*p = w;
	else
		*p = t;

	cout << "address of p " << p << endl;
	cout << "address of w " << &w << endl;
	cout << "address of t " << &t << endl;
}

int main()
{
	int x = 2 , y = 4 , z = 6;
	cout << "address of x " << &x << endl;
	A(&x,y,z);
	cout << "address of x " << &x << endl;
	cout << "address of y " << &y << endl;
	cout << "address of x " << &z << endl;

	std::cout << x << " " << y << " " <<  z << std::endl;
}
