
#include <iostream>

using namespace std;


int *A(int *p, int w, int t )
{
	int *ptr = new int;
	cout << "ptr = " << *ptr << endl;

	if(w > t)
		*p = w;
	else
		*p = t;

	cout << "address of p " << p << endl;
	cout << "address of w " << &w << endl;
	cout << "address of t " << &t << endl;
	*ptr = t;
	return ptr;
}

int main()
{
	int x = 2 , y = 4 , z = 6;
	int *xptr;
	cout << "address of x " << &x << endl;
	xptr = A(&x,y,z);
	cout << xptr << " " << *xptr << endl;
	// Uncomment these two lines to cause program crash
	//delete xptr;
	//xptr = NULL;
	cout << xptr << " " << *xptr << endl;

	cout << "address of x " << &x << endl;
	cout << "address of y " << &y << endl;
	cout << "address of x " << &z << endl;

	std::cout << x << " " << y << " " <<  z << std::endl;
}
