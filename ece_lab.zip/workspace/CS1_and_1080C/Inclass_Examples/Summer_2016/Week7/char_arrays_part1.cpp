
#include <iostream>
#include <string>

using namespace std;

void modifyArray(char Maze[][100])
{
    for(unsigned int row = 0; row < 9; row++)
    {
        for(unsigned int col = 0; col < 15; col++)
        {
            if(Maze[row][col] != '|' && Maze[row][col] != 'd')
                Maze[row][col] = 'P';
        }
    }
}
int main()
{
    char Maze[100][100] = {{'|','|','|','|','|','|','|','|','|','|','|','|','|','|','|'},
                       {'|','n','n','n','n','n','n','|','n','n','n','n','n','n','|'},
                       {'|','n','n','n','n','n','n','|','n','n','n','n','n','n','|'},
                       {'|','n','n','n','n','n','n','n','n','n','n','n','n','n','|'},
                       {'|','n','n','n','n','n','n','n','n','n','n','n','n','n','|'},
                       {'|','n','n','n','n','n','n','n','n','n','n','n','n','n','|'},
                       {'|','n','n','n','|','n','n','n','n','n','|','n','n','n','|'},
                       {'|','n','n','n','|','n','n','n','n','n','|','n','n','n','|'},
                       {'|','|','|','|','|','|','|','|','|','|','|','d','d','d','|'}};

    for(unsigned int row = 0; row < 9; row++)
    {
        for(unsigned int col = 0; col < 15; col++)
        {
            cout << Maze[row][col];
        }
        cout << endl;
    }
    modifyArray(Maze);
    cout << endl;
    for(unsigned int row = 0; row < 9; row++)
    {
        for(unsigned int col = 0; col < 15; col++)
        {
            cout << Maze[row][col];
        }
        cout << endl;
    }


    return 0;
}
