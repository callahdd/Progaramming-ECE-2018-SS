
#include <iostream>
#include <vector>
#include <string>

using namespace std;

int main()
{
    string Maze[] = {{"|||||||||||||||"},
                       {"|nnnnnn|nnnnnn|"},
                       {"|nnnnnn|nnnnnn|"},
                       {"|nnnnnnnnnnnnn|"},
                       {"|nnnnnnnnnnnnn|"},
                       {"|nnnnnnnnnnnnn|"},
                       {"|nnn|nnnnn|nnn|"},
                       {"|nnn|nnnnn|nnn|"},
                       {"|||||||||||ddd|"}};

    for(unsigned int row = 0; row < 9; row++)
    {
        for(unsigned int col = 0; col < Maze[row].length(); col++)
        {
            cout << Maze[row][col];
        }
        cout << endl;
    }
    for(unsigned int row = 0; row < 9; row++)
    {
        for(unsigned int col = 0; col < Maze[row].length(); col++)
        {
            if(Maze[row][col] != '|')
                Maze[row][col] = 'P';
        }
    }
    cout << endl;
    for(unsigned int row = 0; row < 9; row++)
    {
        for(unsigned int col = 0; col < Maze[row].length(); col++)
        {
            cout << Maze[row][col];
        }
        cout << endl;
    }


    return 0;
}
