Files in this weeks folder can be helpful for lab6
