
#include <iostream>
#include <string>
#include <unistd.h>

using namespace std;

void modifyArray(char Maze[][100], int row_len, int col_len, char fill_char)
{
    for(unsigned int row = 0; row < row_len; row++)
    {
        for(unsigned int col = 0; col < col_len; col++)
        {
            //if(Maze[row][col] != '|' && Maze[row][col] != 'd')
                Maze[row][col] = fill_char;
        }
    }
}

void displayArray(char Maze[][100], int row_len, int col_len)
{
    for(unsigned int row = 0; row < row_len; row++)
    {
        for(unsigned int col = 0; col < col_len; col++)
        {

            cout <<     Maze[row][col];
        }
        cout << endl;
    }
}
int main()
{
    char Maze[9][100] = {{"|||||||||||||||"},
                       {"|nnnnnn|nnnnnn|"},
                       {"|nnnnnn|nnnnnn|"},
                       {"|nnnnnnnnnnnnn|"},
                       {"|nnnnnnnnnnnnn|"},
                       {"|nnnnnnnnnnnnn|"},
                       {"|nnn|nnnnn|nnn|"},
                       {"|nnn|nnnnn|nnn|"},
                       {"|||||||||||ddd|"}};


    displayArray(Maze, 9, 15);

    for(int i = 0; i < 26; i++)
    {
        modifyArray(Maze, 9, 15, 'a' + i);
        usleep(750000);
        system("cls");
        displayArray(Maze, 9, 15);
    }
    return 0;
}
