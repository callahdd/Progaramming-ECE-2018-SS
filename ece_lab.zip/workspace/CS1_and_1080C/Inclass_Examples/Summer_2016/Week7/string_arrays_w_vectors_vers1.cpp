
#include <iostream>
#include <vector>
#include <string>
#include <unistd.h>

using namespace std;


void modifyArray(vector <string>& Maze,  char fill_char)
{
    for(unsigned int row = 0; row < Maze.size(); row++)
    {
        for(unsigned int col = 0; col < Maze[row].length(); col++)
        {
            //if(Maze[row][col] != '|' && Maze[row][col] != 'd')
            Maze[row][col] = fill_char;
        }
    }
}

void displayArray(vector <string>Maze, unsigned row_len, unsigned col_len)
{
    for(unsigned int row = 0; row < row_len; row++)
    {
        for(unsigned int col = 0; col < col_len; col++)
        {

            cout << Maze[row][col];
        }
        cout << endl;
    }
}
int main()
{
    vector <string> Maze = {{"|||||||||||||||"},
                            {"|nnnnnn|nnnnnn|"},
                            {"|nnnnnn|nnnnnn|"},
                            {"|nnnnnnnnnnnnn|"},
                            {"|nnnnnnnnnnnnn|"},
                            {"|nnnnnnnnnnnnn|"},
                            {"|nnn|nnnnn|nnn|"},
                            {"|nnn|nnnnn|nnn|"},
                            {"|||||||||||ddd|"}};

    for(unsigned int row = 0; row < Maze.size(); row++)
    {
        for(unsigned int col = 0; col < Maze[row].length(); col++)
        {
            cout << Maze[row][col];
        }
        cout << endl;
    }

    for(int i = 0; i < 26; i++)
    {
        modifyArray(Maze,'a' + i);
        usleep(750000);
        system("cls");
        displayArray(Maze, 9, 15);
    }

    return 0;
}
