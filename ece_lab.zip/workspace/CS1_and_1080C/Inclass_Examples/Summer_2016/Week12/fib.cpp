
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <iomanip>

using namespace std;

static int count = 0;
unsigned int fibonacci_number(int number)
{
    int fibonacci;
    int x1 = 0, x2 = 1;

    if(number == 0)
        return(0);
    if (number == 1)
        return(1);

    for( int i = 2; i <= number; i++)
    {
        fibonacci = x1 + x2;

        x1 = x2;
        x2 = fibonacci;
    }

    return (fibonacci);
}

unsigned int fib_recursive(int F)
{
    if(F == 0 || F == 1) return F;
    count++;
    return fib_recursive(F-1) + fib_recursive(F-2);
}

int main()
{
    clock_t start_t, end_t;

    cout << fixed << setw(3) << "Fib of" << setw(12) << "Fib Number" << setw(14) << "Call Count" << setw(14) << "Calc Time" << endl;
    for(int i = 0; i < 40; i++)
    {
        count = 0;
        start_t = clock();
    	int fnum = fib_recursive(i);
        end_t = clock();
        cout << fixed << setw(3) << i <<"," << setw(12) << fnum <<"," << setw(14) << count <<"," << setw(14)  <<","<< end_t - start_t << endl;
    }

    start_t = clock();
    cout << "fib(25)" << fibonacci_number(25) << endl;
    cout << "fib(35)" << fibonacci_number(35) << endl;
    end_t = clock();
    cout << "time: " << end_t - start_t  << endl;


    return 0;
}

