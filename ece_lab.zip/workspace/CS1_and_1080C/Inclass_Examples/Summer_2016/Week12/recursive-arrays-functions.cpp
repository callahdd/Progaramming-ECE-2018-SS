
#include <iostream>
#include <cstdlib>

using namespace std;

const unsigned int ARRAY_LENGTH = 5;

void randomlyFillArray(int array[], int length){
   for(int i = 0; i < length; i++){
     array[i] = rand()%10;
   }
}

void displayArray(int array[], int length){
   for(int i = 0; i < length; i++){
       cout << array[i] << ",";
   }
   cout << endl;
}

int SumOfArray_iteratively(int array[], int length){
   int sum = 0;
   for(int i = 0; i < length; i++){
       sum += array[i];
   }
   return sum;
}

int SumOfArray_recursive(int array[], int length, int current_sum){
  static int ntimes = 0;
  if(length <= 0) {
   cout << "I was called: " << ntimes << endl;
   return current_sum;
  }
  ntimes++;

  current_sum += array[length-1];
  return SumOfArray_recursive(array, length - 1, current_sum);
}

int main(){
 int *array = new int[ARRAY_LENGTH];

 srand(time(0)/2);
 randomlyFillArray(array, ARRAY_LENGTH);

 displayArray(array, ARRAY_LENGTH);

 cout << SumOfArray_iteratively(array,  ARRAY_LENGTH) << endl;
 cout << SumOfArray_recursive(array,  ARRAY_LENGTH, 0) << endl;

 delete [] array;
}

