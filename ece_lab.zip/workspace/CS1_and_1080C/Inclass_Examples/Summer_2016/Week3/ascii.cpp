// Author: Rob
// Program Name: ascii.cpp
// Description: Displays ASCII table in two different ways using
//		iomanip
// Revision


#include <iostream>
#include <iomanip>

#include <cstdlib>


using namespace std;

int main()
{
  char character = ' ';

  cout << setw(8) << "Decimal" << setw(8) << "ASCII" << endl;

  // while loop version
  while(character <= 126)
  {
    cout << setw(8) << static_cast<int>(character)
         << setw(8) << character
         << "\n";
    character++;
  }


  // for loop version
  // The value of ' ' (or blank) is 32...
  for(character = 32;character <= 126;character++)
  {
    cout << setw(8) << static_cast<int>(character)
         << setw(8) << character;
    cout << "\n";

  }
  return 0;
}
