// Simple Scoping
#include <iostream>
#include <iomanip>

using namespace std;
const int number = 19;

int squareNumber(int number)
{
    number = number*number;
    return number;
}

void IamGlobal()
{
    cout << number << endl;
}


int main()
{
    cout << squareNumber(3) << endl;
    int number = 3;

    cout << squareNumber(number) << endl;
    cout << number << endl;
    IamGlobal();

    return 0;
}
