// Simple Factorial Function

#include <iostream>

using namespace std;

// finish function body
//double pow(double x, double power)
//{
//}

double factorial(double N)
{
    double fact = 1;

    for(double counter = N; counter > 1; counter--)
    {
        fact *= counter;
    }

    return fact;
}

int main()
{
    double N;

    cout << "Enter N: ";
    cin >> N;
    cout << factorial(N) << endl;
}
