// Simple Table with functiions 

#include <iostream>
#include <iomanip>

using namespace std;

int squareNumber(int number)
{
    number = number*number;
    return number;
}

int exponent(int x, int y)
{
    int retval = 1;
    for(int counter = 1; counter <= y; counter++)
    {
        retval *= x; // revtal = retval * x;
    }
    return retval;

}

int main()
{
    for(int i = 0; i <= 10; i++)
    {
        cout << fixed << setw(4) << i << setw(7) << squareNumber(i) <<
                setw(7) << exponent(i, 4) << endl;
    }

    return 0;
}
