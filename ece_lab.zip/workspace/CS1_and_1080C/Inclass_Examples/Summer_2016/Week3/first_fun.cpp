// First Function demo using hello world 

#include <iostream>
#include <string>

using namespace std;


// function prototype
void helloWorld();

// Overloaded function
void helloWorld(string to_be_printed)
{
       cout << to_be_printed << endl;
}

int main()
{
    helloWorld();
    helloWorld("hello bill");
    return 0;
}

// function defination
void helloWorld()
{
    helloWorld("Hello World!");
}
