// Demo showing stacking of switch/case statements

#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    srand(time(0));
    cout << time(0) //<<
           //" \" dfgdf" << time(500000)
         << endl;

    int dice = rand()%6;

    cout << dice << endl;

    switch(dice)
    {
        case 1:
            cout << "1" << endl;
        case 2:
            cout << "2" << endl;
            break;
        case 3:
        case 4:
            cout << "3 or 4" << endl;
            break;
        default:
            cout << "def" << endl;
        break;

    }
    return 0;
}
