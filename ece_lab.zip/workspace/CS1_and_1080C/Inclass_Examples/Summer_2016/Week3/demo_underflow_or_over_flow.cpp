// Author: Rob
// Program Name: demo_underflow_or_over_flow.cpp
// Description: Shows how an infinite can cause a program crash


#include <iostream>
#include <iomanip>

#include <cstdlib>


using namespace std;

int main()
{
  int i = 0;

  // infinite loop 1 using for
  for(;;)
  {
      i++;
      if((i % 100000) == 0)
         cout << i << endl;
  }

  // This one will never be reached.
  // infinite loop 2 using a while
  while(true)
  {
      i++;
      if((i % 100000) == 0)
         cout << i << endl;
  }
  return 0;
}
