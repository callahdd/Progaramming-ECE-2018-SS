
#include <iostream>
#include <iomanip>

using namespace std;

void printValues(string prefix, int *a, int *b, int *c, int *d) {
     cout << prefix << "\ta: " << setw(5) << *a << " b: " << setw(5) << *b << " *c: " 
		<< setw(5) << *c << "  *d: " << setw(5) << *d << " &a: " 
		<< left << setw(15) << a << " &b: " << left << setw(15) << b << " c:  " 
		<< left << setw(15) << c << " d:  " << left << setw(15) << d << endl;
}

int main() {

	int a = 10;
	int b = 20;
	int* c = new int;
	int* d = &b;
	
	printValues("Before: ", &a,&b,c,d);
	cout << endl;

	*d = 15;             printValues("*d = 15;", &a,&b,c,d);

	d = c;               printValues("d = c;  ", &a,&b,c,d);
	
	*d = 12;             printValues("*d = 12;", &a,&b,c,d);
	
	c = &a;              printValues("c = &a; ", &a,&b,c,d);
	
	a = 25;              printValues("a = 25; ", &a,&b,c,d);
	
	*c = 8;              printValues("*c = 8; ", &a,&b,c,d);

	b++;                 printValues("b++;    ", &a,&b,c,d);

	*d = b;              printValues("*d = b; ", &a,&b,c,d);


	cout << endl;
	printValues("After:  ", &a,&b,c,d);
}
