	
	#include <iostream>
	#include <cstdlib>
	
	using namespace std;
	
	struct Node {
	   int x;
	   Node *next;
	};
	
	class LinkedList {
		public:
		LinkedList() { head = NULL ;}
		void DisplayList();
		void PushBack(int val_x);
		void PushFront(int val_x);
		void PopBack();
		int LastValue();
		int LLPos(int value);
		private: 
			Node *head;
	};
	
	void LinkedList::DisplayList() {
	  	Node *temp;
	
		if(head == NULL) {
			cout << "Empty List" << endl;
			return;
		}
	
		temp = head;
	
		while(temp != NULL) {
			cout << temp->x << endl;
			temp = temp->next;
		}
		
	}
	
	void LinkedList::PushFront(int val_x) {
	
		Node *temp;
		Node *newNode = new Node;
		newNode->x = val_x;
		newNode->next = NULL;
	
		if(head == NULL){
			head = newNode;
		}
		else {
			temp = head;
			head = newNode;
			head->next = temp;
		}
	}
	
	void LinkedList::PushBack(int val_x) {
	
		Node *temp;
		Node *newNode = new Node;
		newNode->x = val_x;
		newNode->next = NULL;
	
		if(head == NULL){
			head = newNode;
		}
		else if(head->next == NULL) {
			head->next = temp;
		}
		else {
			temp = head;
			while(temp->next != NULL) {
				temp = temp->next;
			}
			temp->next = newNode;
		}
	}
	
	void LinkedList::PopBack(){
	
		if(head == NULL){
			return;
		}
		else if(head->next == NULL) {
			delete head;
			head = NULL;
		}
		else {
			Node *temp;
			temp = head;
			while(temp->next->next != NULL) {
				temp = temp->next;
			}
			delete temp->next;
			temp->next = NULL;
		}
	} 
	
	int LinkedList::LastValue() {
	
		if(head == NULL){
			return -1;
		}
		else if(head->next == NULL) {
			return head->x;
		}
		else {
			Node *temp;
			temp = head;
			while(temp->next->next != NULL) {
				temp = temp->next;
			}
			return temp->next->x;
		}
	}
	
	
	int LinkedList::LLPos(int search_value) {
		int pos = 0;
	
		if(head == NULL){
			return -1;
		}
		else {
			Node *temp;
			temp = head;
			while(temp != NULL && temp->x != search_value) {
				temp = temp->next;
				pos++;
			}
			if(temp != NULL)
				return pos;
		}
		return -1;
	}
	
	
		int SearchFor(int value);
	int main() {
	
		srand(time(0));
		LinkedList X;
	
		X.DisplayList();
		int val = X.LastValue();
		cout << val << endl;
		X.PushFront(9);
		X.PushFront(rand()%100);
		X.PushFront(rand()%100);
		X.PushBack(rand()%100);
		X.PushBack(rand()%100);
		X.PushBack(200);
	
		cout << "Pos: " << X.LLPos(200) << endl;
		X.DisplayList();
		X.PopBack();
		X.PopBack();
		X.DisplayList();
		cout << "Pos: " << X.LLPos(200) << endl;
	
		val = X.LastValue();
		cout << val << endl;
	}
