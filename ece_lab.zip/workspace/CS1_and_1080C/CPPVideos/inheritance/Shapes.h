/*
	Various shapes to show inheritance.
	Paul Talaga
	September 2015
*/

#include <string>
#include <iostream>
#include <ostream>
#include <cmath>

const float PI = 3.14;

using namespace std;

// Base Shape class
class Shape{
  public:
  Shape(){
    cout << "Base Shape Class Constructor\n";
    color = "Brown";
  }
  
  Shape(string color){
    cout << "Base Shape Class Constructor w/ color\n";
    this->color = color;
  }
  
  virtual ~Shape(){
    cout << "Shape destructor\n";
  }
  
  virtual string getName() const{return "Shape";}
  virtual float getArea() const = 0;  // pure virtual -in herited classes
  virtual float getPerimiter() const = 0; // MUST provide these functions!
  string getColor() const{ return color;};
  
  private:      // Only available in the Shape class!
  string color;
};


class Triangle: public Shape{
  public:
  Triangle(string color):Shape(color){
    cout << "Triangle Class Constructor\n";
    side[0] = 1;
    side[1] = 1;
    side[2] = 1;
  }
  
  Triangle(string color, float s1, float s2, float s3):Shape(color){
    cout << "Triangle Class Constructor w/sides\n";
    side[0] = s1;
    side[1] = s2;
    side[2] = s3;
  }
  
  virtual ~Triangle(){
    cout << "Triangle destructor\n";
  }
  
  virtual string getName() const{ return "Triangle";}
  
  virtual float getPerimiter() const{
    return side[0] + side[1] + side[2];
  }
  
  virtual float getArea() const{
    // Use Heron's Formula
    float p = getPerimiter() / 2.0;
    return sqrt(p * (p - side[0]) * (p - side[1]) * (p - side[2]));
  }
  
  private:
  float side[3];
};

class Square: public Shape{
  public:
  Square(string color):Shape(color){
    cout << "Square class constructor\n";
    side[0] = 1;
    side[1] = 1;
  }
  
  Square(string color, float s1, float s2):Shape(color){
    cout << "Triangle Class Constructor w/sides\n";
    side[0] = s1;
    side[1] = s2;
  }
  
  virtual ~Square(){
    cout << "Square destructor\n";
  }
  
  virtual string getName() const{ return "Square";}
  
  virtual float getPerimiter() const{
    return side[0] + side[1] + side[0] + side[1];
  }
  
  virtual float getArea() const{
    return side[0] * side[1];
  }
  
  private:
  float side[2];
};

class Circle: public Shape{
  public:
  Circle(string color):Shape(color){
    cout << "Circle class constructor\n";
    radius = 1;
  }
  
  Circle(string color, float r):Shape(color){
    cout << "Triangle Class Constructor w/radius\n";
    radius = r;
  }
  
  virtual ~Circle(){
    cout << "Circle destructor\n";
  }
  
  virtual string getName() const{ return "Circle";}
  
  virtual float getPerimiter() const{
    return 2 * PI * radius;
  }
  
  virtual float getArea() const{
    return PI * radius * radius;
  }
  
  private:
  float radius;
};



