/*
	Inheritance driver.
	Paul Talaga
	September 2015
*/

#include <string>
#include <iostream>
#include <vector>
#include <typeinfo>

#include "Shapes.h"

using namespace std;

int main(){
  
  vector<Shape*> table;
  table.push_back(new Triangle("Green"));
  table.push_back(new Triangle("Blue", 4, 5, 6));
  table.push_back(new Square("Red", 2, 5));
  table.push_back(new Circle("Purple"));

  for(unsigned int i = 0; i < table.size(); i++){
    cout << i << ":";
    cout << table[i]->getColor() << " " << table[i]->getName();
    cout << " Area: " << table[i]->getArea();
    cout << " type: " << typeid(*table[i]).name() ;
    cout << endl;
  }  
   
  // return all memory
  for(unsigned int i = 0; i < table.size(); i++){
    delete table[i];
    table[i] = NULL;
  }
  
  
}




