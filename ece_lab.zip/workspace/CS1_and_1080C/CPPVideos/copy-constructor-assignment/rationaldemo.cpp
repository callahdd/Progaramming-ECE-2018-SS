/*
	Rational number demo for Operator overloading and Object conversion
	Paul Talaga
	August 2015
*/

#include <string>
#include <iostream>

#include "Rational.h"

using namespace std;

void printDifferent(Rational rational){
  cout << " " << rational.getNumerator() << endl;
  cout << "----" << endl;
  cout << " " << rational.getDenominator() << endl;
}

int main(){
  Rational a(5);
  cout << "a Numerator: " << a.getNumerator() << endl;
  cout << "b Denominator: " << a.getDenominator() << endl;
  cout << "a: " << a << endl;
  
  Rational b(1,3);
  cout << "b: " << b << endl;
  cout << "a + b = " << a + b << endl;
  cout << "a - b = " << a - b << endl;
  cout << "a * b = " << a * b << endl;
  cout << "b * 15 = " << b * 15 << endl;
  
  if(a == b){
    cout << "a and b are ==\n";
  }else{
    cout << "a and b are not ==\n";
  }
  // Test assignment
  a = b;
  cout << "a: " << a << " b: " << b << endl;
  if(a == b){
    cout << "a and b are ==\n";
  }else{
    cout << "a and b are not ==\n";
  }
  // Explicity test copy constructor
  Rational c(a);
  cout << "a: " << a << endl;
  cout << "c: " << c << endl;
  // Implicity test copy constructor
  cout << "c: " << endl;
  printDifferent(c);
}
