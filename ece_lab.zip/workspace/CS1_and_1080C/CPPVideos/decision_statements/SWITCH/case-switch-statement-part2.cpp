// Author: Rob Montjoy      Date: 1/12/2016
// Source File: case-switch-statement-part2.cpp
// Description: Demostrate the use of a case/switch 
//              statement
// - Removed Magic numbers 
// - Added keyboard input for machine state

#include <iostream>

using namespace std;

const int JOB_RUNNING = 1;
const int MACHINE_WAITING  = 2;
const int JOB_TIMEOUT = 3;
const int MACHINE_HANG = 4;
const int MACHINE_CRASHED = 5;

int main(){
  int machine_state = 1;

  cout << "Input Machine State (1-5):";
  cin >> machine_state;  
  
  cout << "Machine State: ";
  switch(machine_state){
    case JOB_RUNNING:
      cout << "Job Running" << endl;
      break;
      
    case MACHINE_WAITING:
      cout << "Waiting for next Job" << endl;
      break;
    
    case JOB_TIMEOUT:
      cout << "Job Timeout - ";
    case MACHINE_HANG:
    case MACHINE_CRASHED:
      cout << "Malfunctioning" << endl;
      break;
      
    default:
      cout << "Unknown State" << endl;
      break;
  }
    
  return 0;
}

