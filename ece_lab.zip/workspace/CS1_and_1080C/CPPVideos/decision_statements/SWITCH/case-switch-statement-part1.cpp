// Author: Rob Montjoy      Date: 1/12/2016
// Source File: case-switch-statement-part1.cpp
// Description: Demostrate the use of a case/switch statement

#include <iostream>

using namespace std;

int main(){
  int machine_state = 1;
  
  cout << "Machine State: ";
  switch(machine_state)
  {
    case 1:
      cout << "Job Running" << endl;
      break;
      
    case 2:
      cout << "Waiting for next Job" << endl;
      break;
    
    case 3:
      cout << "Job Timeout - ";
    case 4:
    case 5:
      cout << "Malfunctioning" << endl;
      break;
      
    default:
      cout << "Unknown" << endl;
      break;
  }
    
  return 0;
}

