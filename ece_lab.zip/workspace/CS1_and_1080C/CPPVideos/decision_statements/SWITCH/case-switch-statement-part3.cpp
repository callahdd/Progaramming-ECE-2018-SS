// Author: Rob Montjoy      Date: 1/12/2016
// Source File: case-switch-statement-part3.cpp
// Description: Demostrate the use of a case/switch 
//              statement
//              Plus Menu

#include <iostream>
#include <cctype>

using namespace std;

const char UNKNOWN       = 'u';
const char ADD           = 'a';
const char DELETE        = 'd';
const char MODIFY        = 'm';
const char SAVE_RECORDS  = 's';
const char READ_FILE     = 'f';
const char QUIT_W_O_SAVE = 'n';
const char QUIT_W_SAVE   = 'q';


int main(){
  bool exiting = false;
  char menu_action = UNKNOWN; // Set unknown state

  do {
    cout << "Menu" << endl;
    cout << "Action       Selection Character" << endl;
    cout << "Add            " << ADD << endl;
    cout << "Delete         " << DELETE << endl;
    cout << "Modify         " << MODIFY << endl;
    cout << "Save Records   " << SAVE_RECORDS << endl;
    cout << "Read File      " << READ_FILE << endl;
    cout << "Quit W/O Save  " << QUIT_W_O_SAVE << endl;
    cout << "Quit With Save " << QUIT_W_SAVE << endl;
    cout << endl;
  
    cout << "Input Menu Choice: ";
    cin >> menu_action;  
  
    menu_action = tolower(menu_action);
    cout << "Menu Action: ";
    switch(menu_action){
      case ADD:
        cout << "Add a Record to DB" << endl;
        break;
      
      case DELETE:
        cout << "Delete Record from DB" << endl;
        break;
        
      case MODIFY:
        cout << "Modifying Record" << endl;
        break;
        
      case READ_FILE:
        cout << "Reading in new DB file" << endl;
        break;
     
      case SAVE_RECORDS
        cout << "Saving Records to File" << endl;
        break;
        
      case QUIT_W_SAVE:
        cout << "Saving DB Records to file" << endl;
      case QUIT_W_O_SAVE:
        cout << "Exiting Records Program" << endl;
        exiting = true;
        break;
      
      default:
        cout << "Unknown Action" << endl;
        break;
    }
  } while(!exiting);
  return 0;
}

