// Author: Rob Montjoy      Date: 1/12/2016
// Source File: if-statement-w-int.cpp
// Description: Demostrate if statements using the int 
//              variable type

#include <iostream>

using namespace std;

int main(){
  int state1 = 1;
  int state2 = 0;
  
  if(state1 == 1) 
    cout << "state1 is true" << endl;
  
  if(state2 == 0)
    cout << "state2 is false" << endl;
    
  if(state1)
    cout << "state1 is true" << endl;
  else
    cout << "state1 is false" << endl;
    
  if(!state2)
    cout << "state2 is false" << endl;
  else 
    cout << "state2 is true" << endl;
  
  if(state1 == true && state2 == true)
    cout << "Both state1 and state2 are true" << endl;
  else{ 
    if(state1)
      cout << "State1 is true" << endl;
    else 
      cout << "State1 is false" << endl;
    if(state2)
      cout << "State2 is true" << endl;
    else 
      cout << "State2 is false" << endl;
  }
  
  if(state1) {
    if(state2)
      cout << "Both state1 and state2 are true" << endl;
    else
      cout << "State1 is true and state2 is false" << endl;
  }
  else {
    if(!state2)
      cout << "Both state1 and state2 are false" << endl;
    else
      cout << "State1 is false and state2 is true" << endl;
  }
  
  return 0;
}

