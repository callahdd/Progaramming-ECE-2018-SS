// Author: Rob Montjoy      Date: 1/12/2016
// Source File: if-lazy-evaluation.cpp
// Description: Demostrate how lazy evalution works 
//              in c++ if statements

#include <iostream>

using namespace std;

int main(){
  int x = 1; 
  int y = 2;
  
  cout << "x = 1; y = 2; " << endl;
  cout << "if(x++ == 1 || y++ != 2){" << endl;
  if(x++ == 1 || y++ != 2){
    cout << "Inside IF: x = " << x << "\ty = " << y << endl;
  }
  cout << "Outside IF: x = " << x << "\ty = " << y << endl;
  
  x = 1;
  y = 2;
  cout << "x = 1; y = 2; " << endl;
  cout << "if(x++ == 1 && y++ != 2){" << endl;
  if(x++ == 1 && y++ != 2){
    cout << "Inside IF: x = " << x << "\ty = " << y << endl;
  }
  cout << "Outside IF: x = " << x << "\ty = " << y << endl;

  x = 1;
  y = 2;
  cout << "x = 1; y = 2; " << endl;
  cout << "if(x++ != 1 && y++ != 2){" << endl;
  if(x++ != 1 && y++ != 2){
    cout << "Inside IF: x = " << x << "\ty = " << y << endl;
  }
  cout << "Outside IF: x = " << x << "\ty = " << y << endl;
    
  return 0;
}

