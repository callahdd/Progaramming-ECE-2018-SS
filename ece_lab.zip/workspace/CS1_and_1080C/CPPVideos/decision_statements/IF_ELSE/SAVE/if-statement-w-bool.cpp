// Author: Rob Montjoy      Date: 1/12/2016
// Source File: if-statement-w-bool.cpp
// Description: Demostrate if statements using the boolean 
//              variable type

#include <iostream>

using namespace std;

int main()
{
  bool state1 = true;
  bool state2 = false;
  
  if(state1 == true)
    cout << "state1 is true" << endl;
  
  if(state2 == false)
    cout << "state2 is false" << endl;
    
  if(state1)
    cout << "state1 is true" << endl;
  else
    cout << "state1 is false" << endl;
    
  if(!state2)
    cout << "state2 is false" << endl;
  else 
    cout << "state2 is true" << endl;
  
  if(state2 == true && state1 == true)
    cout << "Both state1 and state2 are true" << endl;
  else{ 
    if(state1)
      cout << "State1 is true" << endl;
    else 
      cout << "State1 is false" << endl;
    if(state2)
      cout << "State2 is true" << endl;
    else 
      cout << "State2 is false" << endl;
  }
  
  if(state1) {
    if(state2)
      cout << "Both state1 and state2 are true" << endl;
    else
      cout << "State1 is true and state2 is false" << endl;
  }
  else {
    if(!state2)
      cout << "Both state1 and state2 are false" << endl;
    else
      cout << "State1 is false and state2 is true" << endl;
  }
  
  return 0;
}

