// Author: Rob Montjoy      Date: 1/12/2016
// Source File: if-statement-advanced-part2.cpp
// Description: Demostrate more realistic uses of the
//              if-else cascade construct

#include <iostream>

using namespace std;

int main(){
  float temperature = 100;
  
  cout << "Enter Machine Temperature: ";
  cin >> temperature;
  
  if(temperature <= 0)
    cout << "Machine State: Powered off?" << endl;
  else if(temperature >= 212)
    cout << "Machine State: Overheating" << endl;
  else
    cout << "Machine State: Operating Normally" << endl;
    
  return 0;
}

