// Author: Rob Montjoy      Date: 1/12/2016
// Source File: if-statement-advanced-final.cpp
// Description: Demostrate more realistic uses of the
//              if-else cascade construct
// Change log:
// - Remove Magic Number contstants
// - Improved Styling

#include <iostream>

using namespace std;

const float HI_TEMP = 212;
const float LO_TEMP = 0;

int main(){
  float temperature = 100;
  
  cout << "Enter Machine Temperature: ";
  cin >> temperature;
  
  if(temperature <= LO_TEMP){
    cout << "Machine State: Powered off?" << endl;
  }
  else if(temperature >= HI_TEMP){
    cout << "Machine State: Overheating" << endl;
  }
  else{
    cout << "Machine State: Operating Normally" << endl;
  }
    
  return 0;
}

