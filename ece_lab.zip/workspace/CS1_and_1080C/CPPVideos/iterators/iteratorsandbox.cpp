/*
	Iterator demo using the Linked List class
	Paul Talaga
	September 2015
*/

#include <string>
#include <iostream>
#include <ctime>

#include "LList.h"

using namespace std;


int main(){
  LList<string> a;
  a.push_back("I");
  a.push_back("like");
  a.push_back("pizza.");

  // Slow way
  for(unsigned int i = 0; i < a.size(); i++){
    cout << a.getAt(i) << " ";  //O(n^2)
  }
  cout << endl;
  
  // FAST way!
  for(LListIterator<string> i = a.begin(); i != a.end(); i++){
    cout << *i << " ";  // O(n)
  }
  cout << endl;
  
  // Better speed example--------------------------------
  LList<int> b;
  const int big_size = 40000;
  for(int i = 0; i < big_size; i++){
    b.push_back(i*2);
  }
  
  // Find the sum the slow way.
  int sum1 = 0;
  clock_t startAt = clock();
  for(int i = 0; i < big_size; i++){
    sum1 += b.getAt(i);
  }
  clock_t endAt = clock();
  
  // Find the sum the fast way.
  int sum2 = 0;
  clock_t startIt = clock();
  for(LListIterator<int> i = b.begin(); i != b.end(); i++){
    sum2 += *i;
  }
  clock_t endIt = clock();
  
  cout << endl << "sum1: " << sum1 << " sum2: " << sum2 << endl;
  
  cout << "getAt:" << (float)(endAt - startAt) / (float)CLOCKS_PER_SEC  << " (s)" << endl;
    cout  << "Iterator: " << (float)(endIt - startIt) / (float)CLOCKS_PER_SEC  << " (s)" << endl;
    
}
