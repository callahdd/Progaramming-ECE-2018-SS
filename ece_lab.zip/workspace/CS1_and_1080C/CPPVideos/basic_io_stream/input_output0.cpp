// Author: Rob Montjoy      Date: 1/8/2016
// Source File: input_output0.cpp
// Description: Basic I/O using cin/cout example 0

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
  int x;
  int y;

  // << is the stream insertation operator
  cout << "Enter a value for x: ";
  // >> is the stream extraction operator
  cin >> x;
  // << is the stream insertation operator
  cout << "Enter a value for y: ";
  // >> is the stream extraction operator
  cin >> y;
  
  cout << setw(4) << x << "\t" << setw(4) << y << endl;
  
  cout << "Input both x and y: x space y (ie: 3 4): ";
  cin >> x >> y;
  cout << setw(4) << x << "\t" << setw(4) << y << endl;
  return 0;
}
