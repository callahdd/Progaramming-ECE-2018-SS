// Author: Rob Montjoy      Date: 1/8/2016
// Source File: input_output2.cpp
// Description: Basic I/O using cin/cout example 2

#include <iostream>
#include <iomanip>

#include <string> // String datatype

using namespace std;

int main(){
  int integer_x;
  int result;
  double decimal_y;
  string z_string;

  // << is the stream insertation operator
  cout << "Enter a integer value for x: ";
  // >> is the stream extraction operator
  cin >> integer_x; 
  // << is the stream insertation operator
  cout << "Enter a floating point value for y: ";
  // >> is the stream extraction operator
  cin >> decimal_y; 
  cout << "Enter a value for string z (no spaces allows): ";
  cin >> z_string;
  
  cout << setw(25) << "z string" << setw(12) << "integer x" << "\t" << setw(12) << "decimal y" << endl;
  cout << setw(25) << z_string << setw(12) << integer_x << "\t" << setw(12) << decimal_y << endl;
  
  // String can not contain spaces
  cout << "Input all three varibles on same line: (ie: 3 4.6 string): ";
  cin >> integer_x >> decimal_y >> z_string;
  cout << setw(25) << z_string << setw(12) << integer_x << "\t" << setw(12) << decimal_y << endl;

  result = integer_x * decimal_y;
  cout << setw(10) << "x * y = " << setw(8) << setprecision(4) << result << endl;
  return 0;
}
