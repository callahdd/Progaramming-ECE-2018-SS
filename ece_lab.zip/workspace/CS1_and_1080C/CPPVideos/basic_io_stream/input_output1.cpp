// Author: Rob Montjoy      Date: 1/8/2016
// Source File: input_output1.cpp
// Description: Basic I/O using cin/cout example 1

#include <iostream>
#include <iomanip>

#include <string> // String datatype

using namespace std;

int main(){
  int x;
  int result;
  double y;
  string z;

  // << is the stream insertation operator
  cout << "Enter a value for x: ";
  // >> is the stream extraction operator
  cin >> x;
  // << is the stream insertation operator
  cout << "Enter a value for y: ";
  // >> is the stream extraction operator
  cin >> y;
  cout << "Enter a value string z: ";
  cin >> z;
  
  cout << z << setw(4) << x << "\t" << setw(4) << y << endl;
  
  cout << "Input all three values: (ie: 3 4.4 string): ";
  cin >> x >> y >> z;
  cout << z << setw(4) << x << "\t" << setw(4) << y << endl;
  result = x * y;
  cout << "result: = " << result << endl << endl;
  return 0;
}
