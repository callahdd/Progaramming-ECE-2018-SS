/*
	Rational number demo for exception handling.
	Paul Talaga
	September 2015
*/

#include <string>
#include <iostream>

#include "Rational.h"

using namespace std;

int main(){
  Rational a(5);
  cout << "a Numerator: " << a.getNumerator() << endl;
  cout << "b Denominator: " << a.getDenominator() << endl;
  cout << "a: " << a << endl;
  try{
    Rational b(1,1);
    cout << "b: " << b << endl;
    
    Rational c(0,1);
    
    b = a / c;
    
    cout << "b: " << b << endl;
  }catch(...){
    cout << "Something bad happened in here\n";
  } 
  
  

}




