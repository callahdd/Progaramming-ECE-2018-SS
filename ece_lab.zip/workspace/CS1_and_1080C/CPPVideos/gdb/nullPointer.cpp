/*
	GDB demo for debugging a segmentation fault due 
	to a null/bad pointer.
	Paul Talaga
	October 2015
*/

#include <iostream>

using namespace std;

int main(){
  // Bad address or pointer issue.
  int* a = new int(5);
  int* b = new int(10);
  
  *a = 22;
  b = a;
  
  delete a;
  //delete b;
  
  a = NULL;
  *a = 5;
  
  return 0;
}
