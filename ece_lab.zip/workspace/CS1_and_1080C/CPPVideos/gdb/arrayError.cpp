/*
	GDB demo for debugging a segmentation fault do to an array error.
	Paul Talaga
	October 2015
*/

#include <iostream>

using namespace std;

int getSum(int a[], unsigned int length){
  int ret = 0;
  for(int i = length -1; i >= 0; i--){
    ret += a[i];
  }
  return ret;
}

int main(){
  // Going outside the bounds of an array.
  int numbers[50];
  for(int i = 0; i < 50; i++){
    numbers[i] = i;
  }
  
  cout << "Sum: " << getSum(numbers, 50) << endl;
  
  return 0;
}
