#include <iostream>
#include <string>
#include <cctype>

using namespace std;


bool doesStringContainASpace(const string input_string){
	for(int l = 0; l < input_string.length(); l++){
		if(isspace(input_string.at(l))) return true;
	}
	return false;
}

void removeLetterFromString(string &string_to_be_modified, char letter_to_be_removed){
	int count = 0;
	for(int l = 0; l < string_to_be_modified.length(); l++){
	  if(toupper(string_to_be_modified[l]) != toupper(letter_to_be_removed)) {
		  string_to_be_modified[count] = string_to_be_modified[l];
		  count++;
		}
	}
	//string_to_be_modified.resize(count);
}

int main()
{
	string test = "I H H H H H";
	string test2 = "I H H H H H J K KKKK JHHHh";

  cout << "Test Strings test: " << test; 
  cout << " test2: " << test2 << endl;
  
  cout << "Remove Letter H from test2: " << test2 << endl;
  removeLetterFromString(test2, 'H');
  cout << "After Removal - test2: " << test2 << endl;
  
  if(doesStringContainASpace(test)){
    cout << "Test : " << test << " contains a space.." << endl;
  }else{
    cout << "Test: " << test << " does not contain a space..." << endl;
  }
	return 0;
}


