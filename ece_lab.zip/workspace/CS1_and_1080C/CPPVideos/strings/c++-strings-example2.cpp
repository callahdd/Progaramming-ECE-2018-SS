#include <iostream>
#include <string>
#include <cctype>

using namespace std;

// Mirror string: create a new string with both forward
// and reverse versions of input string and return the results
string MirrorMirror(string string_to_be_modified){
	string new_string;

	for(int i = 0; i < string_to_be_modified.length(); i++)
		new_string += string_to_be_modified[i];

	for(int i = string_to_be_modified.length()-1; i >= 0; i--){
		new_string += string_to_be_modified[i];
	}

	return new_string;
}

// Remove every other letter from input string and return
// new string
string RemoveEveryOtherLetter(string string_to_be_modified){
	string new_string;

	for(int c = 0; c < string_to_be_modified.length(); c = c + 2 ){
		new_string = new_string + string_to_be_modified[c];
	}
		
	return new_string;
} 

// Half lower case and half uppercase
string HalfAndHalf(string string_to_be_modified){

	for(int l = 0; l < string_to_be_modified.length()/2; l++){
		string_to_be_modified[l] = tolower(string_to_be_modified[l]);
	}
	
	for(int u = string_to_be_modified.length()/2; 
		            u < string_to_be_modified.length(); u++){
		string_to_be_modified[u] = toupper(string_to_be_modified[u]);
  }
  
	return string_to_be_modified;
}

int main()
{
	string test = "I H H H H H";
	string test2 = "I H H H H H J K KKKK JHHHh";
	string test3 = "COMET";

  cout << "Strings: test: " << test << " test2: " << test2 << " test3: " << test3 << endl;
  
  cout << "Remove every other letter from test: " << test << endl;
	cout << RemoveEveryOtherLetter(test) << endl;
	cout << "Remove every other letter from test2: " << test2 << endl;
	cout << RemoveEveryOtherLetter(test2) << endl;

  cout << "Half and Half on test: " << test << endl;
	cout << HalfAndHalf(test) << endl;
	cout << "Half and Half on test2: " << test2 
	     << " after removing every other letter" << endl;
	cout << HalfAndHalf(RemoveEveryOtherLetter(test2)) << endl;
  cout << "Mirror test3: " << test3 << endl;
	cout << MirrorMirror(test3) << endl;

	return 0;
}


