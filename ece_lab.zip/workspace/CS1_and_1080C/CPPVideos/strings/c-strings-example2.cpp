// C String Examples 1


#include <cmath>
#include <cstring>
#include <cctype>
#include <iostream>
#include <iomanip>

using namespace std;

int countUpperCaseChars(char string[]){
  unsigned int count = 0;
  for(unsigned int i = 0; i < strlen(string); i++){
    if(isupper(string[i]))
      count++;
  }
  return count;
}

bool stringContainsPunction(char string[]){
  // Search for Punction as soon as it finds it
  // return true
  for(unsigned int i = 0; i < strlen(string); i++){
    if(ispunct(string[i])){
      return true;
    }
  } 
  return false;
}

void convertToLC(char string[]){
  for(unsigned int i = 0; i < strlen(string); i++){
    string[i] = tolower(string[i]);
  }
}

main(){
  // string1 can only hold a string length of 19 because of null termintor
	char string1[20] = "UPPERCASE", string2[] = "Hello", string3[] = "World";

	cout << "The values of string1, string2, and string3 at the program start" << endl;
	cout << "String1: " << string1 << endl;
	cout << "String2: " << string2 << endl;
	cout << "String3: " << string3 << endl;
	
	cout << string1 << " has " << countUpperCaseChars(string1) 
	     << " upper case characters " << endl;
	     
	cout << "Converting String1 to Lowercase" << endl;
	convertToLC(string1);	
	cout << "String1: " << string1 << endl;
	
	strcpy(string1, "");
	strcat(string1, string3);
	strcat(string1, ",");
	strcat(string1, string2);
	
	cout << "After strcat: string1 now contains: " << string1 << endl;
	
	if(stringContainsPunction(string1)) {
	  cout << string1 << " contains punction characters " << endl;
	}else{
		cout << string1 << " does not contain punction characters " << endl;
	}
	if(stringContainsPunction(string2)){
	  cout << string2 << " contains punction characters " << endl;
	}else{
	  cout << string2 << " does not contain punction characters " << endl;
	}
}

