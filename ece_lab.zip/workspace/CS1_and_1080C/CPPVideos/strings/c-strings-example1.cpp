// C String Examples 1


#include <cmath>
#include <cstring>
#include <iostream>
#include <iomanip>

using namespace std;

main(){
  // string1 can only hold a string length of 19 because of null termintor
	char string1[20], string2[] = "Hello", string3[] = "World";

	cout << "The values of string1, string2, and string3 at the program start" << endl;
	cout << "String1: " << string1 << endl;
	cout << "String2: " << string2 << endl;
	cout << "String3: " << string3 << endl;

	// Copy the contents of string2 to string1
	cout << "Copy the contents of string2 to string1" << endl;
	strcpy(string1,string2);
	cout << "String1: " << string1 << endl;
	cout << "String2: " << string2 << endl;
	cout << "String3: " << string3 << endl;

	// Catcatnate the contents onto the end of string1
	cout << "Catcatnate the contents of string3 onto the end of string1"
	     << endl;

	strcat(string1,string3);
	cout << "String1: " << string1 << endl;
	cout << "String2: " << string2 << endl;
	cout << "String3: " << string3 << endl;

	cout << "String length of string1 is " << strlen(string1) << endl;
	cout << "String length of string2 is " << strlen(string2) << endl;
	cout << "String length of string3 is " << strlen(string3) << endl;

	// Is the contains of string1 equal to HelloWorld?
	cout << "Is the contains of string1 equal to HelloWorld?" << endl;
	if((strcmp(string1,"HelloWorld")) == 0)
		cout << "Strings are equal" << endl;
	else 
		cout << "Strings are NOT equal" << endl;

}

