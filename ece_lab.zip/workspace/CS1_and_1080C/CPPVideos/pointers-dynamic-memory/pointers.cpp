/*
	Pointer and dynamic memory demo.
	Paul Talaga
	July 2015
*/

#include <iostream>

using namespace std;

const int SIZE = 20000000;

int main(){
	/*
	int a = 6;
	
	int* b = &a;
	
	*b = 10;
	
	int* c = &a;
	
	cout << "a:" << a << endl;
	cout << "b:" << b << endl;
	cout << "*b:" << *b << endl;
	cout << "c:" << c << endl;
	cout << "*c:" << *c << endl;
	*/
	int b[SIZE];
	int* a = new int[SIZE];
	
	return 0;
	
	for(int i = 0; i < SIZE; i++){
		a[i] = i * 12;
	}
	
	for(int i = 0; i < SIZE; i++){
		if(i % 5 == 0){
			cout << i << ": " << a[i] << endl;
		}
	}
	
	delete a;
	
	return 0;
}