/*
	Dummy Class to demonstrate friends
	Paul Talaga
	August 2015
*/

#include "Rational.h"
#include "Dummy.h"

using namespace std;

Dummy::Dummy(){
  add_count = 0;
}

// This will add Rationals and keep track of how many times it does addition.
Rational Dummy::add(const Rational& left, const Rational& right){
  add_count++;
  // We need to find a common denominator before we add
  int common_denom = left.denominator * right.denominator;
  int left_common_num = left.numerator * right.denominator;
  int right_common_num = right.numerator * left.denominator;
  Rational ret(left_common_num + right_common_num, common_denom);
  ret.simplify();
  return ret;
}

int Dummy::getAddCount(){
  return add_count;
}
