#ifndef DUMMY_H
#define DUMMY_H

/*
	Dummy Class to demonstrate friends
	Paul Talaga
	August 2015
*/
#include <ostream>

using namespace std;

class Rational;   // Forward declaration so this .h file knows to allow Rational
                  // even though it wasn't declared yet.
                  // We can't include Rational.h above because that includes
                  // this file!

class Dummy{

  public:
  Dummy();
  
  Rational add(const Rational& left, const Rational& right);
  
  int getAddCount();
  
  private:
  int add_count;
};



#endif
