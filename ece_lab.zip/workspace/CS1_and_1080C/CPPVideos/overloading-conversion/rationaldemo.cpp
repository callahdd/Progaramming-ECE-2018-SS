/*
	Rational number demo for Operator overloading and Object conversion
	Paul Talaga
	August 2015
*/

#include <string>
#include <iostream>

#include "Rational.h"
#include "Dummy.h"

using namespace std;

int main(){
  Rational a(5);
  cout << "a Numerator: " << a.getNumerator() << endl;
  cout << "b Denominator: " << a.getDenominator() << endl;
  cout << "a: " << a << endl;
  
  Rational b(1,3);
  cout << "b: " << b << endl;
  cout << "a + b = " << a + b << endl;
  cout << "a - b = " << a - b << endl;
  cout << "a * b = " << a * b << endl;
  cout << "b * 15 = " << b * 15 << endl;
  
  if(a == b){
    cout << "a and b are ==\n";
  }else{
    cout << "a and b are not ==\n";
  }
  a = b;
  cout << "a: " << a << " b: " << b << endl;
  if(a == b){
    cout << "a and b are ==\n";
  }else{
    cout << "a and b are not ==\n";
  }
  
  // Demonstration for Friend classes and methods
  Dummy c;
  cout << "Add count: " << c.getAddCount() << endl;
  Rational result = c.add(a,b);
  cout << "Result: " << result << endl;
  cout << "Add count: " << c.getAddCount() << endl;
}




