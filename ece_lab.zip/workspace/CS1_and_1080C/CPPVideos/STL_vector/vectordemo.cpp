/*
	Vector demo.
	Paul Talaga
	Feb 2016
*/

#include <iostream>
#include <vector>

using namespace std;

int getSum(vector<int> vec){
  int sum = 0;
  for(unsigned i = 0; i < vec.size(); i++){
    sum += vec[i];
  }
  return sum;
}

void print(vector<int> vec){
  for(unsigned i = 0; i < vec.size(); i++){
    cout << i << ": " << vec[i] << " ";
  }
  cout << endl;
}

int main(){
	// Declare a new vector that can store ints
	vector<int> myvec;
	
	// Now have the user fill it with values
	while(true){
	  cout << "Vector size: " << myvec.size() << endl;
	  cout << "Vector sum: " << getSum(myvec) << endl;
	  print(myvec);
	  cout << "Number to add?";
	  int number;
	  cin >> number;
	  myvec.push_back(number);
	} 

}
