// Author: Rob Montjoy
// Source File: conditional_operator_table.cpp
// Purpose: To Demostrate basic conditional Operator Table


#include <iostream>
#include <iomanip>

using namespace std;

int main() {
	int x = 1 , y = 0, z = 4;

	cout << setw(35) << "x = 1, y = 0, z = 4"       
       << endl;
       
	cout << setw(35) <<"Less Than Operator: (4 < 3)"  
	     << setw(5) << (4 < 3) << endl;
	     
	cout << setw(35) <<"Greater Than Operator: (x > y)" 
	   << setw(5) << (x > y) << endl;
	   
	cout << setw(35) <<"Equals to Operator: (x == y)"   
	   << setw(5) << (x == y) << endl;
	   
	cout << setw(35) <<"Not Equals to Operator: (x != y)" 
	 << setw(5) << (x != y) << endl;
	 
	cout << setw(35) <<"Greater Than or Equal to: z >= 4" 
	 << setw(5) << (z >= 4) << endl;
	 
	cout << setw(35) <<"Less Than or Equal to:  z <= x*4"
	  << setw(5) << (z <= x*4) << endl;
	
	return 0;
}
