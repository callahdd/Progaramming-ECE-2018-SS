// Author: Rob Montjoy
// Source File:conditional_and_relational_operator_table.cpp
// Purpose: To Demostrate condtional 
//          and relational operators


#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	int x = 1 , y = 0, z = 4;

  cout << "Conditional Operators: " << endl;
	cout << setw(65) << "x = 1, y = 0, z = 4"        
	      << setw(20) << "1/0 or true/false" << endl;
	      
	cout << setw(65) <<"Less Than Operator: (4 < 3)"     
	  << setw(5) << (4 < 3) << endl;
	  
	cout << setw(65) <<"Greater Than Operator: (x > y)"    
	  << setw(5) << (x > y) << endl;
	  
	cout << setw(65) <<"Equals to Operator: (x == y)"    
	  << setw(5) << (x == y) << endl;
	  
	cout << setw(65) <<"Not Equals to Operator: (x != y)"  
	  << setw(5) << (x != y) << endl;
	  
	cout << setw(65) <<"Greater Than or Equal to: z >= 4"
	  << setw(5) << (z >= 4) << endl;
	  
	cout << setw(65) <<"Less Than or Equal to:  z <= x*4"  
	  << setw(5) << (z <= x*4) << endl;
	
	cout << "Relational Operators" << endl;
	cout << setw(65) << "And Operator: (4 != 5 && 5 >  6)" 
	  << setw(5) << (4 != 5 && 5 >  6) << endl;
	  
	cout << setw(65) << "OR Operator: (4 != 5 || 5 >  6)"  
	  << setw(5) << (4 != 5 || 5 >  6) << endl;
	  
	cout << setw(65)
	  << "NOT and OR Operator: (!(4 != 5) || 5 >  6)"  
	  << setw(5) << (!(4 != 5) || 5 >  6) << endl;
	  
	cout << setw(65) 
	     << "NOT, AND, and OR Operator: (((x > y) && (z > 4)) || !(x > 3))" 
	     << setw(5)  
	     << (((x > y) && (z > 4)) || !(x > 3)) << endl;
	     
	return 0;
}
