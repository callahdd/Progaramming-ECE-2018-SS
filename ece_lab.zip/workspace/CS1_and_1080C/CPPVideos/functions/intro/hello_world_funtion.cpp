
// Hello World in functions

#include <iostream>

using namespace std;

// function defination called displayHelloWorld
void displayHelloWorld(){
  cout << "Hello World!" << endl;
}

int main(){
  
  // Function call to display Hello World

  displayHelloWorld();

}
