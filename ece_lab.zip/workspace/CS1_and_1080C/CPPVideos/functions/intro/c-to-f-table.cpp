// C to F conversion table

#include <iostream>
#include <iomanip>

using namespace std;

// Function Protypes
double CtoF(double);
double FtoC(double);

void printCtoFHeader(){
  cout << "Celsius to Fahrenheit table" << endl;
  cout << setw(8) << "C" << setw(10) <<  "F" << endl;
}

void printFtoCHeader(){
  cout << "Fahrenheit to Celsius table" << endl;
  cout << setw(8) << "F" << setw(10) <<  "C" << endl;
}

main(){
  printCtoFHeader();
  
  for(double C = 0; C <= 100; C++){
    F = CtoF(C);
    cout << fixed << setprecision(1) << showpoint
         << setw(8)   << C
         << setw(10)  << F
         << endl;
  }


  printFtoCHeader();
  
  for(double F = 32; F <= 212; F++){
    cout << fixed << setprecision(1) << showpoint
         << setw(8)   << F
         << setw(10)  << FtoC(F)
         << endl;
  }
}

// Function Definations
double FtoC(double F){
  return((5.0/9.0)*(F  - 32.0));
}

double CtoF(double C){
  return((C*9.0/5.0) + 32.0);
}

