// Basic Scoping Demo part 1
// For local variable
#include <iostream>

using namespace std;

int add(int a, int b){
  int answer = a + b; // Unnecessary temporary value
  return answer;
}

int main(){

  int answer, a, b;

  cout << "Demo to Sum two integers" << endl;
  cout << "Enter Interger a: ";
  cin >> a;
  cout << "Enter Interger b: ";
  cin >> b;

  answer = add(a, b);

  cout << "Answer: " << answer << endl;

  cout << "Or without temporary variable answer:" << endl;

  cout << "Answer: " << add(a, b) << endl;

  return 0;
}

