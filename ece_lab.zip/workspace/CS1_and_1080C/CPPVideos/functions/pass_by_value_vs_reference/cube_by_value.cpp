// cube_by_value.c
// Routine to compute the volume of cube using call-by-value.
// Orignal Author: Deitel & Deitel
// Orignal Revision date: 02-09-95 Original definition


#include <iostream>

using namespace std;

// This function is a call by value. Note: It does not have any operator
// associated it with it.
int cubeByValue(int);

main(){
  int number = 5;

  cout << "The number to cube = " << number << endl;
  number = cubeByValue(number);
  cout << "The cube of number = " << number << endl;

  return 0;
}

int cubeByValue(int n){
  return n * n * n;  // cube local variable n
}

