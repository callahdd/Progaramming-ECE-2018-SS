//
// cube_by_ref.cpp
//
// Routine to compute the volume of cube using call-by-reference.

// Revised to use the new C++ reference operator by Rob on 3/2/2014

#include <iostream>

using namespace std;

// The & (reference operator) in the function prototype means it is a call by "reference"
// This operator should not be confused with the pointer operator (*). They are similar but not the same.

void cubeByReference(int &);

main(){
  int number = 5;

  cout << "The number to cube = " << number << endl;
  cubeByReference(number);
  cout << "The cube of number = " << number << endl;

  return 0;
}

// Pass by Reference operator &
void cubeByReference(int &nPtr){
  nPtr = nPtr * nPtr * nPtr;  // cube number in main
}

