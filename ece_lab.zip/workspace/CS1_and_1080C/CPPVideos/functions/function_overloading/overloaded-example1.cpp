// Basic Demo of function overloading

#include <iostream>
using namespace std;

// The & (reference operator) in the function prototype means it is a call by "reference"
// This operator should not be confused with the pointer operator (*). They are similar but not the same.
void cubeIt(double &);

// This function is a call by value. Note: It does not have any operator
// associated it with it.
int cubeIt(int);

main(){
  int number = 5;
  double number2 = number;

  cout << "The number to cube = " << number << endl;
  cubeIt(number);
  cout << "The cube of number = " << number << endl;

  cout << "The number to cube = " << number << endl;
  number = cubeIt(number);
  cout << "The cube of number = " << number << endl;

  return 0;
}

// Pass by Reference operator &
void cubeIt(double &nPtr){
  nPtr = nPtr * nPtr * nPtr;  // cube number in main
}

// Pass by Reference operator &
int cubeIt(int n){
  return n*n*n;  // cube number in main
}


