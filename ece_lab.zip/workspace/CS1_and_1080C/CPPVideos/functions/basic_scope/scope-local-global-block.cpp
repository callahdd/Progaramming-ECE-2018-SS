// Basic Scoping Demo part 3
// For local and global variables

#include <iostream>

using namespace std;

// A few global variables
int a = 2 , b = 102, answer;

// A different int a and int b 
int add1(int a, int b){
	return a + b;
}

// A different int a and int b 
int add2() {
	cout << "Value of global variable a: " << a << endl;
	cout << "Value of global variable b: " << b << endl;
	return a + b;
}

int main(){

	// A different int a and int b 
	int answer, a, b;

	cout << "Demo to Sum two integers" << endl;
	cout << "Enter Interger a: ";
	cin >> a;
	cout << "Enter Interger b: ";
	cin >> b;
	cout << "Answer: " << add1(a, b) << endl;

	cout << "Lets add the two global variables" << endl;
	cout << "Global Variable Answer: " << add2() << endl;

	// Begin new block
	{
		int a = 67, b = 33;

		cout << "Block Scope" << endl;
		cout << "a = " << a << endl;
		cout << "b = " << b << endl;
		cout << "Result of a + b" << add1(a,b) << endl;
	}
	cout << "Out of block scope" << endl;
	
	cout << "a = " << a << endl;
	cout << "b = " << b << endl;

	return 0;
}


