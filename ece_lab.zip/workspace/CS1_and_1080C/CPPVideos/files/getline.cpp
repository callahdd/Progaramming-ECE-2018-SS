/*
	File input demo using getline.
	Paul Talaga
	July 2015
*/

#include <iostream>
#include <string>
#include <fstream>

using namespace std;

int main(int argc, char **argv){
	fstream file;
	file.open(argv[1], ios::in);
	if(file.fail()){
		cout << "Error opening file " << argv[1] << "\n";
		return 1;
	}
	
	string line;
	int i = 0;
	getline(file, line);
	while(file){
	//while(file >> line){
		cout << i << ": " << line << endl;
		i++;
		getline(file, line);
	}
	file.close();
	
	return 0;
}