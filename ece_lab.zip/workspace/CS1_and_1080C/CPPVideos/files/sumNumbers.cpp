/*
	File input demo.
	Sums and counts a file full of numbers, one per line.
	Paul Talaga
	July 2015
*/

#include <iostream>
#include <string>
#include <fstream>

using namespace std;

int main(int argc, char **argv){
	fstream file;
	file.open(argv[1], ios::in);
	if(file.fail()){
		cout << "Error opening file " << argv[1] << "\n";
		return 1;
	}
	
	int sum = 0;
	int count = 0;
	int number;
	while(file >> number){
		sum = sum + number;
		count++;
	}
	file.close();
	
	cout << "Sum: " << sum << endl;
	cout << "Count: " << count << endl;
	
	
	return 0;
}
