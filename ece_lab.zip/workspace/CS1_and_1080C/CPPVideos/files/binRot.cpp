/*
	Binary file reading/writing demo.
	This rotates each byte of an input file by a given amount and
	saves the result to an output file.
	Paul Talaga
	July 2015
*/

#include <iostream>
#include <string>
#include <fstream>

using namespace std;

int main(int argc, char **argv){
	if( argc != 4){
		cout << "Usage: a.out infile outfile rotation\n";
		return 1;
	}
	fstream fin;
	fin.open(argv[1], ios::in | ios::binary);
	if(fin.fail()){
		cout << "Error opening file " << argv[1] << "\n";
		return 1;
	}
	
	fstream fout;
	fout.open(argv[2], ios::out | ios::binary);
	
	char character;
	fin.get(character);
	int i = 0;
	while(fin){
		fout.put(character + atoi(argv[3]));
		fin.get(character);
		i++;
	}
	fin.close();
	fout.close();
	cout << "Converted " << i << " bytes.\n";
	
	return 0;
}