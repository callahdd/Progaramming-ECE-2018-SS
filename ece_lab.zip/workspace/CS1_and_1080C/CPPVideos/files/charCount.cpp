/*
	File input demo.
	Paul Talaga
	July 2015
*/

#include <iostream>
#include <string>
#include <fstream>

using namespace std;

int main(int argc, char **argv){
	fstream file;
	file.open(argv[1], ios::in);
	if(file.fail()){
		cout << "Error opening file " << argv[1] << "\n";
		return 1;
	}
	
	int counts[26]; // Create array to house counts
	for(int i = 0; i < 26;i++){ 	// Initialize to 0's
		counts[i] = 0;
	}
	
	char character;
	while(file >> character){ // Pull off characters till you can't
		cout << "Saw: " << character << endl;
		if(character >= 'a' && character <= 'z'){ // If lower increment
			counts[character - 'a']++;
		}
	}
	file.close();
	
	for(int i = 0; i < 26; i++){
		cout << (char)(i+'a') << ": " << counts[i] << endl;
	}
	
	return 0;
}