// Author: Rob Montjoy
// Source File: c++_operator_demo2.cpp
// Purpose: To Demostrate basic c++ "short hand" operators.

#include <iostream>

using namespace std;

int main(){
	int x = 1 , y = 2, z = 4;
	double h = 5.3, g = 6.7;

	int integer_result = 0;
	double decimal_result = 0;

	cout << "int x = 1 , y = 2, z = 4;" << endl;
	cout << "double h = 5.3, g = 6.7;" << endl;
	
  x += 2;
	cout << "x += 2; " << "x = " << x << endl;
	x -= 4;
	cout << "x -= 4; " << "x = " << x << endl;
	h *= g; 
	cout << "h *= g; " << "h = " << h << endl;
	
	cout << "x = " << x << " x++; " << "x = ";
	x++;
	cout << x << endl;
	
	cout << "y = " << y << " --y; " << "y = " ;
	--y;
	cout << y << endl;
	
	cout << "x = " << x << " z = x++;";
	z = x++;
	cout << " z = " << z << " x = " << x << endl;
	
	cout << "y = " << y << " z = --y;";
  z = --y;
	cout << " z = " << z << " y = " << y << endl;
	
	cout << "y = " << y << " z = y--;";
  z = y--;
	cout << " z = " << z << " y = " << y << endl;
	
	return 0;
}
