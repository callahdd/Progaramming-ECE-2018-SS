// Author: Rob Montjoy
// Source File: c++_operator_demo1.cpp
// Purpose: To Demostrate basic c++ operators.
// We will include precedence and associtivity

#include <iostream>

using namespace std;

int main() {
	int x = 1 , y = 2, z = 4;
	double h = 5.3, g = 6.7;

	int integer_result = 0;
	double decimal_result = 0;

	cout << "int x = 1 , y = 2, z = 4;" << endl;
	cout << "double h = 5.3, g = 6.7;" << endl;
	integer_result = h * y + z;
	cout << "integer_result = h * y + z;" 
	  << " = " << integer_result << endl;
	decimal_result = h * y + z;
	
	cout  << "decimal_result = h * y + z;" 
	  << " = " << decimal_result << endl;

	integer_result = h * (y + z);
	cout  << "integer_result = h * (y + z);" 
	  << " = " << integer_result << endl;
	decimal_result = h * (y + z);
	cout  << "decimal_result = h * (y + z);" 
	  << " = " << decimal_result << endl;
	
	integer_result = h * y / z + 2 - 8;
	cout  << "integer_result = h * y / z + 2 - 8;" 
	  << " = " << integer_result << endl;
	
	integer_result = h * y / (z + 2) - 8;
	cout  << "integer_result = h * y / (z + 2) - 8;" 
	  << " = " << integer_result << endl;
	
	integer_result = -h * y / ((z + 2) - 8);
	cout  << "integer_result = -h * y / ((z + 2) - 8);" 
	  << " = " << integer_result << endl;
	
	integer_result = static_cast<int>(h) % (int)g;
	cout  << "integer_result = static_cast<int>(h) % (int)g;" 
	  << " = " << integer_result << endl;
	
	integer_result = z % y;
	cout  << "integer_result = z % y;" 
	  << " = " << integer_result << endl;
	
	integer_result = y % z;
	cout  << "integer_result = y % z;" 
	  << " = " << integer_result << endl;
	
	return 0;
}
