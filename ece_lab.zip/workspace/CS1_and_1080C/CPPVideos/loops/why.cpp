#include <iostream>

using namespace std;

int main(){
  cout << "Sum of number from 1 to 10:\n";
  int result = 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10;
  cout << result << endl;
  
  return 0;
}
