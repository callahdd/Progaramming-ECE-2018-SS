#include <iostream>

using namespace std;

int main(){
  
  do{
    cout << "You ran me in a do/while loop!\n";
  }while( false ); 
  
  while( false){
    cout << "You ran me in a while loop!\n";
  }
  
  for(;;){
    cout << "You ran me in a for loop!\n";
  }
  
  return 0;
}
