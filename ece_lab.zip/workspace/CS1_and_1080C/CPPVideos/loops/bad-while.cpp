#include <iostream>

using namespace std;

int main(){

  cout << "Let me count for you....\n";
  int counter = 0;
  
  while( counter <= 20 ){
    cout << "Counter value: " << counter << endl;
  }
  
  return 0;
}
