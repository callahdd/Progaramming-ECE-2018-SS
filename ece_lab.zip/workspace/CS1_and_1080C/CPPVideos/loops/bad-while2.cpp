#include <iostream>

using namespace std;

int main(){

  cout << "Let me count down from 20 for you....\n";
  unsigned int counter = 20;
  
  while( counter >= 0 ){
    cout << "Counter value: " << counter << endl;
    counter--;
  }
  
  
  return 0;
}
