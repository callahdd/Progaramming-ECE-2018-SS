#include <iostream>

using namespace std;

int main(){
  cout << "How happy are you? (scale from 1-10)";
  int times;
  cin >> times;
  for(int i = 0; i < times; i++){
    cout << "[" << i +1 <<"] Very happy" << endl;
  }
  
}
