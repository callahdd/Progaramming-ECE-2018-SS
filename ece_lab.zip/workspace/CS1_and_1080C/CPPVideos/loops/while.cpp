#include <iostream>

using namespace std;

int main(){

  int ans = 0;
  float gpa = 4.0;
  
  while( ans == 0 ){
    cout << "Your GPA is " << gpa << endl;
    cout << "Did you go to class today?";
    cin >> ans;
    if(ans == 0){
      gpa -= 0.1;
    }
  }
  
  cout << "\nFinally!  Good job!\n";
  
  cout << "Your final GPA is: " << gpa << endl;
  
  return 0;
}
