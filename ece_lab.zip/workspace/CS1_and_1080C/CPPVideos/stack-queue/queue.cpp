/*
	STL Queue demo.
	Paul Talaga
	September 2015
*/

#include <string>
#include <iostream>
#include <queue>

using namespace std;

int main(){

  queue<string> s;
  // empty(), size(), T front(), push(T), pop()
  
  cout << "Size: " << s.size() << endl;
  cout << "Empty?: " << s.empty() << endl << endl;
  
  s.push("Something");
  cout << "front: " << s.front() << endl;
  cout << "Size: " << s.size() << endl << endl;
  
  s.push("More");
  cout << "front: " << s.front() << endl;
  cout << "Size: " << s.size() << endl << endl;
  
  s.pop();
  cout << "front: " << s.front() << endl;
  cout << "Size: " << s.size() << endl;
  cout << "Empty?: " << s.empty() << endl << endl;
  
  s.pop();
  cout << "Size: " << s.size() << endl;
  cout << "Empty?: " << s.empty() << endl << endl;
  
  
  return 0;
}
