/*
	STL Stack demo.
	Paul Talaga
	September 2015
*/

#include <string>
#include <iostream>
#include <stack>

using namespace std;

int main(){

  stack<string> s;
  // empty(), size(), T top(), push(T), pop()
  
  cout << "Size: " << s.size() << endl;
  cout << "Empty?: " << s.empty() << endl << endl;
  
  s.push("Something");
  cout << "top: " << s.top() << endl;
  cout << "Size: " << s.size() << endl << endl;
  
  s.push("More");
  cout << "top: " << s.top() << endl;
  cout << "Size: " << s.size() << endl << endl;
  
  s.pop();
  cout << "top: " << s.top() << endl;
  cout << "Size: " << s.size() << endl;
  cout << "Empty?: " << s.empty() << endl << endl;
  
  s.pop();
  cout << "Size: " << s.size() << endl;
  cout << "Empty?: " << s.empty() << endl << endl;
  
  
  return 0;
}
