// Rob Montjoy
// DescriptioN: Simple 2D Array
// 

#include <iostream>
#include <cstdlib>
#include <iomanip>

using namespace std;

// All C/C++ arrays start at element location zero (0)

void display2DArray(float array[][20], int row_count, int col_count){

  for(int r = 0; r < row_count; r++){
    for(int c = 0; c < col_count; c++){
      cout << fixed << setw(5) << setprecision(1) << array[r][c] << " ";
    }
    cout << endl;
  }
}

void InitArray(float array[][20], int row_count, int col_count){

  for(int r = 0; r < row_count; r++){
    for(int c = 0; c < col_count; c++){
      array[r][c] = c*r;
    }
  }
}

int main(){
  float two_Ddata[10][20]; 
  int row_count = 10;
  int col_count = 20;

  // You can not print out values stored in an array by doing the
  // following. Instead the address of the array is printed instead

  cout << "Some Pointer Math" << endl;
  cout << "Address of array: " << two_Ddata << endl;
  cout << "Address of array + 1: " << two_Ddata + 1 << endl;
  cout << "Address of array + 2: " << two_Ddata + 2 << endl;
  cout << "Address of array + 3: " << two_Ddata + 3 << endl;

  cout << "What values does array start out with?" << endl;
  display2DArray(two_Ddata, row_count, col_count);

  cout << "Looks like some random junk so lets " << endl;
  cout << "Load array with row * col" << endl;
  InitArray(two_Ddata, row_count, col_count);

  cout << "Display array" << endl;
  display2DArray(two_Ddata, row_count, col_count);


}

