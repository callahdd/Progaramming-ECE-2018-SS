// Rob Montjoy
// DescriptioN: Simple 2D Array
// 

#include <iostream>
#include <cstdlib>
#include <iomanip>

using namespace std;

// All C/C++ arrays start at element location zero (0)

void display2DArray(float array[][5], int row_count, int col_count){

  cout << "Columns";
  for(int c = 0; c < col_count; c++){
      cout << fixed << setw(5) << setprecision(1) << c << " ";
  }
  cout << endl;
  for(int r = 0; r < row_count; r++){
    cout << setw(5) << "row: " << fixed << setw(4) << r < " ";
    for(int c = 0; c < col_count; c++){
      cout << fixed << setw(5) << setprecision(1) << array[r][c] << " ";
    }
    cout << endl;
  }
}

void copy2DArrays(float dest[][5], float source[][5], int row_count, int col_count){
  for(int r = 0; r < row_count; r++){
    for(int c = 0; c < col_count; c++){
      dest[r][c] = source[r][c];
    }
  }
}
void InitArray(float array[][5], int row_count, int col_count){

  for(int r = 0; r < row_count; r++){
    for(int c = 0; c < col_count; c++){
      array[r][c] = drand48();
    }
  }
}

int main(){
  float two_Ddata_source[10][5]; 
  float two_Ddata_dest[10][5]; 
  int row_count = 10;
  int col_count = 5;
 
  srand48(time(0));

  cout << "Load array with random small values" << endl;
  InitArray(two_Ddata_source, row_count, col_count);
  InitArray(two_Ddata_dest, row_count, col_count);

  cout << "Display array source" << endl;
  display2DArray(two_Ddata_source, row_count, col_count);

  cout << "Display array dest" << endl;
  display2DArray(two_Ddata_dest, row_count, col_count);

  cout << "Copy source to dest" << endl;
  copy2DArrays(two_Ddata_dest, two_Ddata_source, row_count, col_count);

  cout << "Display array source after copy" << endl;
  display2DArray(two_Ddata_source, row_count, col_count);

  cout << "Display array dest after copy" << endl;
  display2DArray(two_Ddata_dest, row_count, col_count);

}

