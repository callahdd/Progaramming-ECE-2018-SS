// Rob Montjoy
// Simple Array
// 

#include <iostream>
#include <cstdlib>

using namespace std;

const int TOTAL_RANDOM_NUMBER_COUNT = 100000;

void fillFrequencyArray(int fc_array_length, int frequency_count[]){

  for(int random_count = 0; random_count 
                < TOTAL_RANDOM_NUMBER_COUNT; random_count++){
                
    int random_number = rand()%fc_array_length;
	
    frequency_count[random_number] += 1;
  }
}

void displayArray(int array_length, int array[]){
  for(int i = 0; i < array_length; i++){
    cout << "index: " << i << "\tvalue: " << array[i] << endl;
  }
}

int main(){
  int frequency_count[10]  = {0};
  int fc_array_length = 10;
 
  srand(time(0));
  fillFrequencyArray(fc_array_length, frequency_count);
  displayArray(fc_array_length, frequency_count);
}

