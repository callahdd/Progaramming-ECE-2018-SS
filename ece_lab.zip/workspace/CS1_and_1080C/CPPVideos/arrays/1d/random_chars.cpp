// Rob Montjoy
// Simple Array
// 

#include <iostream>
#include <cstdlib>

using namespace std;


// all lowercase letters
void randomCharArray(unsigned array_length, char c_array[]){
  for(int i = 0; i < array_length; i++){
	  c_array[i] = rand()%array_length + 'a';
  }
}

void displayArray(unsigned array_length, char array[]){
  for(int i = 0; i < array_length; i++){
    cout << "index: " << i << "\tvalue: " << array[i] << endl;
  }
}

// Assume the first value is the max value
// Loop to the end of the array while searching for a max value
char findMaxCharValue(unsigned array_length, char array[]){
  char max_value = array[0];

  for(int i = 1; i < array_length; i++){
    if(array[i] > max_value){
      max_value = array[i];
    }
  }
  return max_value;
}

int main(){
  char random_char_array[26]  = {0};
  unsigned rc_array_length = 26;
 
  srand(time(0));
  randomCharArray(rc_array_length, random_char_array);
  displayArray(rc_array_length, random_char_array);

  char max_value = findMaxCharValue(rc_array_length,
       random_char_array);

  cout << "Max Value: " << max_value << endl;
}

