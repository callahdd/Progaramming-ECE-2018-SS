// Rob Montjoy
// Simple Array
// 

#include <iostream>
#include <cstdlib>

using namespace std;

// All C/C++ arrays start at element location zero (0)
int main(){
  int x[10] = {0}, array_length = 10;

  // You can not print out values stored 
  // in an array by doing the
  // following. Instead the address of the 
  // array is printed instead

  cout << "Address of array x: " << x << endl;

  // But instead you have to iterate through 
  // the array starting at location 0
  // and going through size of array minus 1


  // Display array starting at beginning (element 0)
  // and going to end (length of array - 1)
  for(int i = 0; i < array_length;  i++){
    cout << "index: " << i << "\tvalue: " 
         << x[i] << endl;
  }

}

