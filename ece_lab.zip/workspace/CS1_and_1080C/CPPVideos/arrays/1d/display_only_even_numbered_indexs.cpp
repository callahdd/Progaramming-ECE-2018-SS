// Rob Montjoy
// Description: Display every other array element
// 

#include <iostream>
#include <cstdlib>

using namespace std;

int main(){
  // Initialize the first 4 elements to specific values 
  // All others become a value of 0
  int x[10]  = {1,2,3,4};
  int array_length = 10;

  // Just display even numbered array elements (note: i += 2)
  for(int i = 0; i < 10 ;  i += 2){
    cout << "index: " << i << "\tvalue: " << x[i] << endl;
  }

}

