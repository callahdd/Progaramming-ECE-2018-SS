// Programmer:	Rob Montjoy
// File:	primes.cpp
// Description:	This program determines whether a range of numbers
//		is prime(up to the value of MAX_PRIME_NUMBER).
//
//		It uses the Sieve of Erastothenes method to
//		to determine these prime numbers.


#include <iostream>
using std::endl;
using std::cout;

#define MAX_PRIME_NUMBER 50  // Search the first 50 numbers for primes

// Declare Function Return types and argument types
void FindPrimes(long MaxPrime,long primes[]);
void InitializeArray(long MaxPrime,long primes[]);
void PrintPrimes(long MaxPrime,long primes[]);

// Main Function
main(void){
  // Declare Local Variables
  long MaxPrime = MAX_PRIME_NUMBER; // Maximum prime number
  // to search for
  long primes[MAX_PRIME_NUMBER];

  // Initialize Prime Number Array
  InitializeArray(MaxPrime,primes);

  // Find Prime Numbers from 2 to MaxPrime
  FindPrimes(MaxPrime,primes);

  // Print the Prime Numbers
  PrintPrimes(MaxPrime,primes);
}

// Function Name: InitializeArray
// Purpose: Initialize elements in a long array to 0
// Arguments:  long array_length	- number elements in an array
//	       long array		- long int array to initialize to 0

void InitializeArray(long array_length, long array[]){
  for(long i = 0; i < array_length; i++){
    array[i] = 0L;
  }
}

// Function Name: FindPrimes
// Purpose:  Find Prime Numbers from 2 to MaxPrime.
//       A 1 in the primes array indicates that the number is not prime
//	     and a 0 indicates a prime number
// Arguments: MaxPrime	- Maximum number of "prime" numbers to search for
//	      primes	- Array used to indicate which number is prime.

void FindPrimes(long MaxPrime, long primes[]){
  // Need to document
  for(long i=2; i <= MaxPrime; i++)
  {
    for( long j = i; j <= MaxPrime; j++){
      if((j*i) <= MaxPrime) primes[i*j] = 1;
    }
  }
}

// Function Name: PrintPrimes
// Purpose:  Print Prime Numbers from 2 to MaxPrime.
//       A 1 in the primes array indicates that the number is not prime
//	     and a 0 indicates a prime number
// Arguments: MaxPrime	- Maximum number of "prime" numbers to search in the
//			  array for printing
//	      primes	- Array used to indicate which number is prime.

void PrintPrimes(long MaxPrime, long primes[]){
  // Print Header
  cout << "The following is a list of prime numbers:" << endl;
  for(long i=2; i <= MaxPrime; i++){
    if(primes[i] == 0){
      cout << i << " is a Prime Number" << endl;
    }
  }
}

