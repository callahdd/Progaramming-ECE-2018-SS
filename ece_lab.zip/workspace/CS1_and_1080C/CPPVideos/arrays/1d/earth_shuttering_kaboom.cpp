// Rob Montjoy
// Loop forever until segmentation fault.
// 

#include <iostream>
#include <cstdlib>

using namespace std;

int main(){
  int x[10], array_length = 10;

  // Loop forever until program crashes
  // Program will crash when you hit the top of the stack
  for(int i = 0;;i++){
    cout << "index: " << i << "\tvalue: " << x[i] << endl;
  }

}

