// arrays.cpp
// simple demo of arrays


#include <iostream>
using namespace std;

// function prototype
void ModifyArray(int intarray[], int arraycount ) ;

// function main declaration
int main (){
  // declare a counter index
  int i;
  // declare an array with 10 elements
  int myarray[10] = { 0 } ;

  // declare a variable to hold the count (# of elements) of the array
  int count ;

  // compute the count (# of elements) of the array
  // this works in main because myarray is local to main
  count = sizeof myarray / sizeof(myarray[0]);
  cout << "\nIn function main.\nmyarray has " << count << " elements." << endl;

  // display current contents of array
  cout << "Original values in main:" << endl;
  for (i = 0; i < count; i++){
    cout << "myarray[" << i << "] = " << myarray[i] << endl;
  }
  cout << endl;

  // call function ModifyArray
  // pass the count as a parameter so function knows how big the array is
  ModifyArray(myarray, count );

  // display current contents of array (after function call)
  cout << "\nReturned from function ModifyArray\nModified values:" << endl;
  for (i = 0; i < count; i++){
    cout << "myarray[" << i << "] = " << myarray[i] << endl ;
  }

  // compute the count (# of elements) of the array
  // this works in main because myarray is local to main
  count = sizeof myarray / sizeof(myarray[0]);
  cout << "\nIn function main.\nmyarray has " << count << " elements." << endl;

  return 0;
}

void ModifyArray(int intarray[] , int arraycount){
  int i;

  cout << "\nLOOK!  I am now in ModifyArray!" << endl;

  // display current contents of array (after function call)
  cout << "\nIn function ModifyArray\nArray values:" << endl;
  for (i = 0; i < arraycount; i++){
    cout << "intarray[" << i << "] = " << intarray[i] << endl ;
  }

  // modify the array; store the loop index value in each element of the array
  int c ;
  for (c = 0; c < 10; c++){
    intarray[c] = c ;
  }

  // display current contents of array (after function call)
  cout << "\nStill in function ModifyArray\nModified values:" << endl;
  for (i = 0; i < arraycount; i++){
    cout << "intarray[" << i << "] = " << intarray[i] << endl ;
  }


  // *********** LOOK *******************
  // You cannot compute the size of an array in a function
  // if the array is not local to the function
  // This next command executes but doesn't work right
  arraycount = sizeof(intarray) / sizeof(intarray[0]) ;
  cout << "\nInaccurate result of count calculation:\n" ;
  cout << "intarray has " << arraycount << " elements." << endl << endl ;

  return;
} // end of function ModifyArray()

