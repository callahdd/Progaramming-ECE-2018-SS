// Rob Montjoy
// Display array in Reverse for highest index to lowest index.
// 

#include <iostream>
#include <cstdlib>

using namespace std;

// Count down from array length minus one to zero

void  displayArrayInReverse(unsigned int array_length, double x[]) {
  for(int i = array_length - 1; i >= 0;  i--){
    cout << "index: " << i << "\tvalue: " << x[i] << endl;
  }
}

int main(){

  // Size is automatically calculated from number of initializing
  // Elements
  double x[]  = {1.5, 2.3, 3.4, 4.1, 8.9};

  // Do some fancy sizeof calcutions to determine array length
  // Remember sizeof returns the value at compile time of the
  // size of array x in bytes. Divid total bytes by the size 
  // of a double data type
  
  unsigned int array_length = sizeof(x)/sizeof(double);

  displayArrayInReverse(array_length, x);

}

