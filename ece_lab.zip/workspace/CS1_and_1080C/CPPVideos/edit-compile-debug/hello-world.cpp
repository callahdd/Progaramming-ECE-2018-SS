// Name: Paul Talaga
// Test

#include <iostream>

using namespace std;

int main(){
  cout << "Hello World\n";
  cout << "This is for fun" << endl;
  
  return 0;
}
