#ifndef MYFUNC_TEST_H
#define MYFUNC_TEST_H

#include "myfunctions.cpp"

#include <iostream>
#include <cxxtest/TestSuite.h>

using namespace std;

// This requires CxxTest to be installed!
// For this CPPVideos example, navigate your terminal to CPPVideos and type:
// git submodule init
// git submodule update
// This will add the public CxxTest repository INSIDE the current repo.
// The current Makefile in this directory assumes cxxtest is a folder one
// level down.

class MyTests : public CxxTest::TestSuite {
public:
 
  void testSum1() {
    TS_ASSERT_EQUALS(sum(1,1), 2);
  }
  
  void testSum2() {
    TS_ASSERT_EQUALS(sum(10,10), 20);
  }
  
  void testSum3() {
    TS_ASSERT_EQUALS(sum(-1,-1), -2);
  }
  
  void testSum4() {
    TS_ASSERT_EQUALS(sum(10,10,10), 30);
  }
  
  void testSum5() {
    TS_ASSERT_EQUALS(sum(10,10,10,10), 40);
  }
  
  void testMean1() {
    TS_ASSERT_DELTA(mean(0,0), 0, 0.0001);
  }
  
  void testMean2() {
    TS_ASSERT_DELTA(mean(1,2), 1.5, 0.0001);
  }
  
  void testMean3() {
    TS_ASSERT_DELTA(mean(-5.5,5.5), 0, 0.0001);
  }
  
  void testMean4() {
    TS_ASSERT_DELTA(mean(12345.6, 23456.7), 17901.15, 0.0001);
  }
  
  void testEncrypt1() {
    TS_ASSERT(encrypt("hello",0) == "hello");
  }
  
  void testEncrypt2() {
    TS_ASSERT(encrypt("abcde",1) == "bcdef");
  }
  
  void testEncrypt3() {
    TS_ASSERT_EQUALS(encrypt("Aabcde",1), "Abcdef");
  }
  
  void testEncrypt4() {
    TS_ASSERT_EQUALS(encrypt("AaA BbB",2), "AcA BdB");
  }
  
  void testEncrypt5() {
    TS_ASSERT_EQUALS(encrypt("bcdef",-1), "abcde");
  }
  
  // This will fail!
  void testEncrypt6() {
    TS_ASSERT_EQUALS(encrypt("z",1), "a");
  }
  
};


#endif
