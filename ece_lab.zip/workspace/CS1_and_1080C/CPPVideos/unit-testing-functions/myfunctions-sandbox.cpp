/*
	Simple function sandbox
	Paul Talaga
	Feb 2016
*/

#include <string>
#include <iostream>

#include "myfunctions.cpp"

using namespace std;

int main(){
  cout << "Sum of 5 and 6 is " << sum(5,6) << endl;
  cout << "Sum of 9 and 10 is " << sum(9,10) << endl;
  cout << "Sum of 1,2,3 is " << sum(1,2,3) << endl;
  cout << "Sum of 1,2,3,4 is " << sum(1,2,3,4) << endl;
  
  cout << "Mean of 5 and 6 is " << mean(5,6) << endl;
  
  cout << "Encrypt 'bob' by 1 " << encrypt("bob",1) << endl;
  return 0;	
}
