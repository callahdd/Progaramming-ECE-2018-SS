#ifndef MYFUNC_H
#define MYFUNC_H
/*
	Simple functions
	Paul Talaga
	Feb 2016
*/
#include <string>

using namespace std;

// Adds the given values and returns the sum.
int sum(int a, int b, int c = 0, int d = 0){
	return a + b + c + d;
}

// Returns the mean of the two values.
double mean(double a, double b){
	return (a + b) / 2;
}

// Performs a caesar cipher on the input string given a
// rotation amount.  Can handle negative rotations.
// Will only encrypt lower-case letters.
// TODO: Fix for wraparound!
string encrypt(string input, int rotation){
	string ret(input); 	// Make a copy of the string
	for(unsigned i = 0; i < input.length(); i++){
		if(input[i] >= 'a' && input[i] <= 'z'){
			ret[i] = input[i] + rotation;
		}
		// else don't change it!
	}
	return ret;
}

#endif
