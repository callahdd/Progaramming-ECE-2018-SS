/*
	A simple reimplementation of the vector container class using templates.
	Paul Talaga
	September 2015
*/
#include <iostream>
#include <stdexcept>
#include <ostream>

#include "MyVec.h"

  
using namespace std;

MyVec::MyVec(){
  s = 0;
  capacity = 2;
  things = new int[2];
};
  
MyVec::~MyVec(){
  delete[] things;  // Note that since things is a pointer to an array, we need
                    // to use the delete that handles arrays.
}
 
int MyVec::operator[](int i) const{
  return at(i);
}
 
int MyVec::at(int i) const{
  // Allow negative values to index backward from the end
  if(i < 0){
    i = s + i;
  }
  if(static_cast<unsigned int>(i) >= s || i < 0){
    throw logic_error("Index out of bounds");
  }
  return things[i];
};

void MyVec::push_back(int word){
  // Will another element fit in my current array?
  if(s == capacity){ // I need more!
    capacity = capacity * 2;  // Increase by 2 every time to even out the
    int* temp = new int[capacity];  // cost of copying all the data.
    for(unsigned int i = 0; i < s; i++){
      temp[i] = things[i];
    }
    delete[] things;
    things = temp;
  }
  things[s] = word;
  s++;
}
  
unsigned int MyVec::size() const{
  return s;
}

ostream& operator<<(ostream& out, const MyVec& v){
  out << "[";
  for(unsigned int i = 0; i < v.size(); i++){
    if( i < v.size() -1){
      out << v.at(i) << ", ";
    }else{
      out << v.at(i);
    }
  }
  out << "]";
  return out;
}
  
  
