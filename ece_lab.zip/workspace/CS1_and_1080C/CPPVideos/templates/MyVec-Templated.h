#ifndef MYVEC_H
#define MYVEC_H
/*
	A simple reimplementation of the vector container class using templates.
	Paul Talaga
	September 2015
*/

#include <string>
#include <ostream>
#include <stdexcept>

using namespace std;

template <class T>
class MyVec{
  public:
  
  MyVec(){
    s = 0;
    capacity = 2;
    things = new T[2];
  };
  
  ~MyVec(){
    delete[] things;  // Note that since things is a pointer to an array, we need
                      // to use the delete that handles arrays.
  }
  
  T at(int i) const{
    // Allow negative values to index backward from the end
    if(i < 0){
      i = s + i;
    }
    if(static_cast<unsigned int>(i) >= s || i < 0){
      throw logic_error("Index out of bounds");
    }
    return things[i];
  };
  
  T operator[](int i) const{
    return at(i);
  }
  
  void push_back(T thing){
    // Will another element fit in my current array?
    if(s == capacity){ // I need more!
      capacity = capacity * 2;  // Increase by 2 every time to even out the
      T* temp = new T[capacity];  // cost of copying all the data.
      for(unsigned int i = 0; i < s; i++){
        temp[i] = things[i];
      }
      delete[] things;
      things = temp;
    }
    things[s] = thing;
    s++;
  }
  
  unsigned int size() const{
    return s;
  }
  
  private:
  
  T* things;
  unsigned int s;
  unsigned int capacity;
  
};

template <class T>
ostream& operator<<(ostream& out, const MyVec<T>& v){
  out << "[";
  for(unsigned int i = 0; i < v.size(); i++){
    if( i < v.size() -1){
      out << v.at(i) << ", ";
    }else{
      out << v.at(i);
    }
  }
  out << "]";
  return out;
}

#endif
