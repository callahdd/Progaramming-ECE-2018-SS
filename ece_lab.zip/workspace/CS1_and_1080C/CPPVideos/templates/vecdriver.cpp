/*
	A demonstrator for the MyVec class using templates.
	Paul Talaga
	September 2015
*/
#include <string>
#include <iostream>
#include <vector>
#include <cstdlib>

//#include "MyVec.h"
#include "MyVec-Templated.h"


using namespace std;


int main(){
  
  srand(time(0));
  
  MyVec<float> a;
  
  for(uint i = 0; i < 10; i++){
    a.push_back(rand() % 10 + 0.5);
  }
  
  for(uint i = 0; i < a.size(); i++){
    cout << i << ":" << a[i] << endl;
  }
  
  cout << "Vector: " << a << endl;
  
  cout << "Last element: " << a[-1] << endl;

}
